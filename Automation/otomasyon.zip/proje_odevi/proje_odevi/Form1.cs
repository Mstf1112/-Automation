using FontAwesome.Sharp;
using System.Runtime.InteropServices;
using System.Data.SqlClient;
using System.Data;

namespace proje_odevi
{
    public partial class Form1 : Form
    {
        private IconButton currentBtn;
        private Panel menu_btn;
        private Form form_olustur;

        DateTime baslangicSaat = DateTime.Today.AddHours(9); // Ma�aza a��l�� zaman� belirleme  
        DateTime bitisSaat = DateTime.Today.AddHours(19); // Ma�aza kapan�� zaman� belirleme
        



        public Form1()
        {
            InitializeComponent();
            timer1.Start();



            menu_btn = new Panel();
            menu_btn.Size = new Size(7, 60);

            this.Text = string.Empty;
            this.ControlBox = false;
            this.DoubleBuffered = true;
            this.MaximizedBounds = Screen.FromHandle(this.Handle).WorkingArea;

        }

       

        // Veritaban� ba�lant�s� olu�turma  

        static string constring = "Data Source=FURKAN\\SQLEXPRESS;Initial Catalog=Nalbur_DB;Integrated Security=True;";
        SqlConnection baglanti = new SqlConnection(constring);



        private struct RGBColors
        {
            public static Color color1 = Color.FromArgb(172, 126, 241);
            public static Color color2 = Color.FromArgb(249, 118, 176);
            public static Color color3 = Color.FromArgb(253, 138, 114);
            public static Color color4 = Color.FromArgb(95, 77, 221);


        }


        // Sol taraftaki men� butonlar�n�n a��k oldu�u durumda �al��acak buton �zellikleri
        private void Aktif_Button(object senderBtn, Color color)
        {
            if (senderBtn != null)
            {
                Kapali_Button();

                //Buton

                currentBtn = (IconButton)senderBtn;



                currentBtn.BackColor = Color.FromArgb(247, 247, 247);
                currentBtn.ForeColor = color;
                currentBtn.TextAlign = ContentAlignment.MiddleCenter;
                currentBtn.IconColor = color;
                currentBtn.TextImageRelation = TextImageRelation.TextBeforeImage;
                currentBtn.ImageAlign = ContentAlignment.MiddleRight;

                //Men� Butonlar�

                menu_btn.BackColor = color;
                menu_btn.Location = new Point(0, currentBtn.Location.Y);
                menu_btn.Visible = true;
                menu_btn.BringToFront();


            }
        }

        // Sol taraftaki men� butonlar�n�n kapal� oldu�u durumda �al��acak buton �zellikleri
        private void Kapali_Button()
        {
            if (currentBtn != null)
            {


                currentBtn.BackColor = Color.FromArgb(247, 247, 247);

                currentBtn.TextAlign = ContentAlignment.MiddleLeft;

                currentBtn.TextImageRelation = TextImageRelation.ImageBeforeText;
                currentBtn.ImageAlign = ContentAlignment.MiddleLeft;
            }
        }
         // Orta k�s�mda bulunan child form sisteminin yarat�l�� k�sm�
        private void form_yarat(Form yeni_form)
        {
            //tek sayfada form a�ma

            if (form_olustur != null)
            {
                form_olustur.Close();
            }
            form_olustur = yeni_form;

            //*

            yeni_form.TopLevel = false;
            yeni_form.FormBorderStyle = FormBorderStyle.None;
            yeni_form.Dock = DockStyle.Fill;
            yeni_form.BringToFront();
            yeni_form.Show();
            panel17.Controls.Add(yeni_form);
            panel17.Tag = yeni_form;
        }



        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                {
                    baglanti.Open();

                    // Sa� tarafta bulunan men� k�sm�ndaki g�nl�k sat�� k�sm�
                    string query = "SELECT SUM(ToplamTutar) FROM Siparisler WHERE SiparisTarihi = @SiparisTarihi";
                    using (SqlCommand command = new SqlCommand(query, baglanti))
                    {
                        command.Parameters.AddWithValue("@SiparisTarihi", DateTime.Today); 
                        object result = command.ExecuteScalar();

                        if (result != null && result != DBNull.Value)
                        {
                            decimal ToplamTutar = Convert.ToDecimal(result);
                            label7.Text = $"Bug�n�n Sipari� Toplam Tutar�: {ToplamTutar:tl}";
                        }
                        else
                        {
                            label7.Text = "Bug�n sipari� bulunmamaktad�r.";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }


        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void panel13_Paint(object sender, PaintEventArgs e)
        {

        }








        // Oturum kapatma k�sm�ndaki buton
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            giris_ekrani Kayit_Ekrani = new giris_ekrani();
            Kayit_Ekrani.Show();
            this.Hide();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void FormMainMenu_Resize(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Maximized)
                FormBorderStyle = FormBorderStyle.None;
            else
                FormBorderStyle = FormBorderStyle.Sizable;
        }







        private void panel17_Paint(object sender, PaintEventArgs e)
        {

        }






        // Sol men�m�zdeki butonlar�n �zerine uygulanan �zellikleri bar�ndan k�s�m
        private void urunler_Click(object sender, EventArgs e)
        {
            Aktif_Button(sender, RGBColors.color1);
            form_yarat(new urunler());
        }

        private void satislar_Click(object sender, EventArgs e)
        {
            Aktif_Button(sender, RGBColors.color2);
            form_yarat(new satislar());
        }

        private void kargo_Click(object sender, EventArgs e)
        {
            Aktif_Button(sender, RGBColors.color3);
            form_yarat(new kargo());
        }

        private void personel_Click(object sender, EventArgs e)
        {
            Aktif_Button(sender, RGBColors.color4);
            form_yarat(new personel());
        }






        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }






        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void maximize_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
                WindowState = FormWindowState.Maximized;
            else
                WindowState = FormWindowState.Normal;
        }

        private void minimize_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }


        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click_1(object sender, EventArgs e)
        {
            if (form_olustur != null)
            {
                form_olustur.Close();
            }
            Reset();
        }

        
        private void Reset()
        {
            Kapali_Button();
            form_olustur.Close();
            menu_btn.Visible = false;

        }

        // Ma�azan�n a��k veya kapal� oldu�u durumlar� sorgulad���m�z alan
        private void timer1_Tick(object sender, EventArgs e)
        {
            TimeSpan kalanSure = bitisSaat - DateTime.Now;

            if (DateTime.Now >= baslangicSaat && DateTime.Now <= bitisSaat)
            {
                label12.Text = $"Kalan s�re: {kalanSure.Hours} saat {kalanSure.Minutes} dakika {kalanSure.Seconds} saniye";
            }
            else if (DateTime.Now < baslangicSaat)
            {
                label12.Text = $"Ba�lang�� saati bekleniyor: {baslangicSaat.Subtract(DateTime.Now).ToString(@"hh:mm:ss")}";
            }
            else
            {
                label12.Text = "Geriye say�m tamamland�!";
                timer1.Stop();
            }
        }
    }
}
