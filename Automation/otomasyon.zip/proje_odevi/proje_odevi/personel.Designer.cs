﻿namespace proje_odevi
{
    partial class personel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(personel));
            label1 = new Label();
            panel2 = new Panel();
            pictureBox1 = new PictureBox();
            panel21 = new Panel();
            panel20 = new Panel();
            panel18 = new Panel();
            panel19 = new Panel();
            label3 = new Label();
            panel14 = new Panel();
            panel15 = new Panel();
            label16 = new Label();
            textBox5 = new TextBox();
            panel12 = new Panel();
            panel13 = new Panel();
            label10 = new Label();
            comboBox1 = new ComboBox();
            button5 = new Button();
            panel16 = new Panel();
            panel17 = new Panel();
            label17 = new Label();
            maskedTextBox1 = new MaskedTextBox();
            panel10 = new Panel();
            panel11 = new Panel();
            label11 = new Label();
            textBox4 = new TextBox();
            button4 = new Button();
            panel8 = new Panel();
            panel9 = new Panel();
            label12 = new Label();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            panel6 = new Panel();
            panel7 = new Panel();
            label13 = new Label();
            comboBox2 = new ComboBox();
            button3 = new Button();
            panel4 = new Panel();
            panel5 = new Panel();
            label14 = new Label();
            maskedTextBox2 = new MaskedTextBox();
            panel1 = new Panel();
            panel3 = new Panel();
            label15 = new Label();
            textBox1 = new TextBox();
            button2 = new Button();
            button1 = new Button();
            dataGridView1 = new DataGridView();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel14.SuspendLayout();
            panel12.SuspendLayout();
            panel16.SuspendLayout();
            panel10.SuspendLayout();
            panel8.SuspendLayout();
            panel6.SuspendLayout();
            panel4.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(437, 291);
            label1.Name = "label1";
            label1.Size = new Size(66, 20);
            label1.TabIndex = 1;
            label1.Text = "personel";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(247, 247, 247);
            panel2.Controls.Add(pictureBox1);
            panel2.Controls.Add(panel21);
            panel2.Controls.Add(panel20);
            panel2.Controls.Add(panel18);
            panel2.Controls.Add(panel19);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(panel14);
            panel2.Controls.Add(panel12);
            panel2.Controls.Add(button5);
            panel2.Controls.Add(panel16);
            panel2.Controls.Add(panel10);
            panel2.Controls.Add(button4);
            panel2.Controls.Add(panel8);
            panel2.Controls.Add(textBox3);
            panel2.Controls.Add(panel6);
            panel2.Controls.Add(button3);
            panel2.Controls.Add(panel4);
            panel2.Controls.Add(panel1);
            panel2.Controls.Add(button2);
            panel2.Controls.Add(button1);
            panel2.Controls.Add(dataGridView1);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Margin = new Padding(3, 4, 3, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(815, 851);
            panel2.TabIndex = 7;
            panel2.MouseEnter += panel2_MouseEnter;
            panel2.MouseLeave += panel2_MouseLeave;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(685, 145);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(22, 23);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 72;
            pictureBox1.TabStop = false;
            // 
            // panel21
            // 
            panel21.Anchor = AnchorStyles.None;
            panel21.BackColor = Color.LightGray;
            panel21.Location = new Point(95, 724);
            panel21.Margin = new Padding(3, 4, 3, 4);
            panel21.Name = "panel21";
            panel21.Size = new Size(1, 73);
            panel21.TabIndex = 71;
            // 
            // panel20
            // 
            panel20.Anchor = AnchorStyles.None;
            panel20.BackColor = Color.LightGray;
            panel20.Location = new Point(95, 833);
            panel20.Margin = new Padding(3, 4, 3, 4);
            panel20.Name = "panel20";
            panel20.Size = new Size(617, 1);
            panel20.TabIndex = 70;
            // 
            // panel18
            // 
            panel18.Anchor = AnchorStyles.None;
            panel18.BackColor = Color.LightGray;
            panel18.Location = new Point(711, 724);
            panel18.Margin = new Padding(3, 4, 3, 4);
            panel18.Name = "panel18";
            panel18.Size = new Size(1, 73);
            panel18.TabIndex = 70;
            // 
            // panel19
            // 
            panel19.Anchor = AnchorStyles.None;
            panel19.BackColor = Color.LightGray;
            panel19.Location = new Point(95, 689);
            panel19.Margin = new Padding(3, 4, 3, 4);
            panel19.Name = "panel19";
            panel19.Size = new Size(617, 1);
            panel19.TabIndex = 69;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.FromArgb(93, 62, 188);
            label3.Location = new Point(325, 29);
            label3.Name = "label3";
            label3.Size = new Size(144, 29);
            label3.TabIndex = 68;
            label3.Text = "PERSONEL";
            // 
            // panel14
            // 
            panel14.BackColor = Color.Transparent;
            panel14.Controls.Add(panel15);
            panel14.Controls.Add(label16);
            panel14.Controls.Add(textBox5);
            panel14.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel14.ForeColor = Color.Transparent;
            panel14.Location = new Point(440, 515);
            panel14.Margin = new Padding(3, 4, 3, 4);
            panel14.Name = "panel14";
            panel14.Size = new Size(248, 112);
            panel14.TabIndex = 67;
            // 
            // panel15
            // 
            panel15.Anchor = AnchorStyles.None;
            panel15.BackColor = Color.LightGray;
            panel15.Location = new Point(5, 80);
            panel15.Margin = new Padding(3, 4, 3, 4);
            panel15.Name = "panel15";
            panel15.Size = new Size(237, 1);
            panel15.TabIndex = 30;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.BackColor = Color.Transparent;
            label16.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label16.ForeColor = Color.FromArgb(93, 62, 188);
            label16.Location = new Point(0, 0);
            label16.Name = "label16";
            label16.Size = new Size(18, 15);
            label16.TabIndex = 56;
            label16.Text = "İD";
            // 
            // textBox5
            // 
            textBox5.Location = new Point(9, 45);
            textBox5.Margin = new Padding(3, 4, 3, 4);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(231, 21);
            textBox5.TabIndex = 17;
            // 
            // panel12
            // 
            panel12.BackColor = Color.Transparent;
            panel12.Controls.Add(panel13);
            panel12.Controls.Add(label10);
            panel12.Controls.Add(comboBox1);
            panel12.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel12.ForeColor = Color.Transparent;
            panel12.Location = new Point(440, 407);
            panel12.Margin = new Padding(3, 4, 3, 4);
            panel12.Name = "panel12";
            panel12.Size = new Size(248, 112);
            panel12.TabIndex = 65;
            // 
            // panel13
            // 
            panel13.Anchor = AnchorStyles.None;
            panel13.BackColor = Color.LightGray;
            panel13.Location = new Point(5, 80);
            panel13.Margin = new Padding(3, 4, 3, 4);
            panel13.Name = "panel13";
            panel13.Size = new Size(237, 1);
            panel13.TabIndex = 30;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label10.ForeColor = Color.FromArgb(93, 62, 188);
            label10.Location = new Point(0, 0);
            label10.Name = "label10";
            label10.Size = new Size(58, 15);
            label10.TabIndex = 56;
            label10.Text = "İzin Günü";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar" });
            comboBox1.Location = new Point(9, 44);
            comboBox1.Margin = new Padding(3, 4, 3, 4);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(231, 23);
            comboBox1.TabIndex = 5;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(93, 62, 188);
            button5.FlatAppearance.BorderColor = Color.FromArgb(93, 62, 188);
            button5.FlatAppearance.BorderSize = 2;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button5.ForeColor = Color.White;
            button5.Location = new Point(398, 629);
            button5.Margin = new Padding(3, 4, 3, 4);
            button5.Name = "button5";
            button5.Size = new Size(145, 47);
            button5.TabIndex = 26;
            button5.Text = "Personeli Güncelle";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            button5.MouseEnter += button5_MouseEnter;
            button5.MouseLeave += button5_MouseLeave;
            // 
            // panel16
            // 
            panel16.BackColor = Color.Transparent;
            panel16.Controls.Add(panel17);
            panel16.Controls.Add(label17);
            panel16.Controls.Add(maskedTextBox1);
            panel16.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel16.ForeColor = Color.Transparent;
            panel16.Location = new Point(123, 515);
            panel16.Margin = new Padding(3, 4, 3, 4);
            panel16.Name = "panel16";
            panel16.Size = new Size(248, 112);
            panel16.TabIndex = 66;
            // 
            // panel17
            // 
            panel17.Anchor = AnchorStyles.None;
            panel17.BackColor = Color.LightGray;
            panel17.Location = new Point(5, 81);
            panel17.Margin = new Padding(3, 4, 3, 4);
            panel17.Name = "panel17";
            panel17.Size = new Size(237, 1);
            panel17.TabIndex = 30;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.BackColor = Color.Transparent;
            label17.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label17.ForeColor = Color.FromArgb(93, 62, 188);
            label17.Location = new Point(0, 0);
            label17.Name = "label17";
            label17.Size = new Size(97, 15);
            label17.TabIndex = 56;
            label17.Text = "Başlangıç Tarihi";
            // 
            // maskedTextBox1
            // 
            maskedTextBox1.Location = new Point(9, 45);
            maskedTextBox1.Margin = new Padding(3, 4, 3, 4);
            maskedTextBox1.Mask = "00/00/0000";
            maskedTextBox1.Name = "maskedTextBox1";
            maskedTextBox1.Size = new Size(231, 21);
            maskedTextBox1.TabIndex = 21;
            maskedTextBox1.ValidatingType = typeof(DateTime);
            // 
            // panel10
            // 
            panel10.BackColor = Color.Transparent;
            panel10.Controls.Add(panel11);
            panel10.Controls.Add(label11);
            panel10.Controls.Add(textBox4);
            panel10.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel10.ForeColor = Color.Transparent;
            panel10.Location = new Point(440, 299);
            panel10.Margin = new Padding(3, 4, 3, 4);
            panel10.Name = "panel10";
            panel10.Size = new Size(248, 112);
            panel10.TabIndex = 63;
            // 
            // panel11
            // 
            panel11.Anchor = AnchorStyles.None;
            panel11.BackColor = Color.LightGray;
            panel11.Location = new Point(5, 77);
            panel11.Margin = new Padding(3, 4, 3, 4);
            panel11.Name = "panel11";
            panel11.Size = new Size(237, 1);
            panel11.TabIndex = 30;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.Transparent;
            label11.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label11.ForeColor = Color.FromArgb(93, 62, 188);
            label11.Location = new Point(0, 0);
            label11.Name = "label11";
            label11.Size = new Size(95, 15);
            label11.TabIndex = 56;
            label11.Text = "Personel Maaşı";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(9, 43);
            textBox4.Margin = new Padding(3, 4, 3, 4);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(231, 21);
            textBox4.TabIndex = 4;
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(93, 62, 188);
            button4.FlatAppearance.BorderColor = Color.FromArgb(93, 62, 188);
            button4.FlatAppearance.BorderSize = 2;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button4.ForeColor = Color.White;
            button4.Location = new Point(254, 629);
            button4.Margin = new Padding(3, 4, 3, 4);
            button4.Name = "button4";
            button4.Size = new Size(128, 47);
            button4.TabIndex = 25;
            button4.Text = "Personel Sil";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            button4.MouseEnter += button4_MouseEnter;
            button4.MouseLeave += button4_MouseLeave;
            // 
            // panel8
            // 
            panel8.BackColor = Color.Transparent;
            panel8.Controls.Add(panel9);
            panel8.Controls.Add(label12);
            panel8.Controls.Add(textBox2);
            panel8.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel8.ForeColor = Color.Transparent;
            panel8.Location = new Point(440, 187);
            panel8.Margin = new Padding(3, 4, 3, 4);
            panel8.Name = "panel8";
            panel8.Size = new Size(248, 112);
            panel8.TabIndex = 61;
            // 
            // panel9
            // 
            panel9.Anchor = AnchorStyles.None;
            panel9.BackColor = Color.LightGray;
            panel9.Location = new Point(5, 79);
            panel9.Margin = new Padding(3, 4, 3, 4);
            panel9.Name = "panel9";
            panel9.Size = new Size(237, 1);
            panel9.TabIndex = 30;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.Transparent;
            label12.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label12.ForeColor = Color.FromArgb(93, 62, 188);
            label12.Location = new Point(0, 0);
            label12.Name = "label12";
            label12.Size = new Size(45, 15);
            label12.TabIndex = 56;
            label12.Text = "Soyadı";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(9, 44);
            textBox2.Margin = new Padding(3, 4, 3, 4);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(231, 21);
            textBox2.TabIndex = 2;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(95, 143);
            textBox3.Margin = new Padding(3, 4, 3, 4);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(617, 27);
            textBox3.TabIndex = 24;
            // 
            // panel6
            // 
            panel6.BackColor = Color.Transparent;
            panel6.Controls.Add(panel7);
            panel6.Controls.Add(label13);
            panel6.Controls.Add(comboBox2);
            panel6.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel6.ForeColor = Color.Transparent;
            panel6.Location = new Point(123, 407);
            panel6.Margin = new Padding(3, 4, 3, 4);
            panel6.Name = "panel6";
            panel6.Size = new Size(248, 112);
            panel6.TabIndex = 64;
            // 
            // panel7
            // 
            panel7.Anchor = AnchorStyles.None;
            panel7.BackColor = Color.LightGray;
            panel7.Location = new Point(5, 83);
            panel7.Margin = new Padding(3, 4, 3, 4);
            panel7.Name = "panel7";
            panel7.Size = new Size(237, 1);
            panel7.TabIndex = 30;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.Transparent;
            label13.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label13.ForeColor = Color.FromArgb(93, 62, 188);
            label13.Location = new Point(0, 0);
            label13.Name = "label13";
            label13.Size = new Size(58, 15);
            label13.TabIndex = 56;
            label13.Text = "Pozisyon";
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "Satış Temsilcisi", "Yönetici" });
            comboBox2.Location = new Point(9, 44);
            comboBox2.Margin = new Padding(3, 4, 3, 4);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(231, 23);
            comboBox2.TabIndex = 6;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(93, 62, 188);
            button3.FlatAppearance.BorderColor = Color.FromArgb(93, 62, 188);
            button3.FlatAppearance.BorderSize = 2;
            button3.FlatStyle = FlatStyle.Flat;
            button3.ForeColor = Color.White;
            button3.Location = new Point(317, 79);
            button3.Margin = new Padding(3, 4, 3, 4);
            button3.Name = "button3";
            button3.Size = new Size(171, 40);
            button3.TabIndex = 23;
            button3.Text = "Personel Ara";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            button3.MouseEnter += button3_MouseEnter;
            button3.MouseLeave += button3_MouseLeave;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Transparent;
            panel4.Controls.Add(panel5);
            panel4.Controls.Add(label14);
            panel4.Controls.Add(maskedTextBox2);
            panel4.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel4.ForeColor = Color.Transparent;
            panel4.Location = new Point(123, 299);
            panel4.Margin = new Padding(3, 4, 3, 4);
            panel4.Name = "panel4";
            panel4.Size = new Size(248, 112);
            panel4.TabIndex = 62;
            // 
            // panel5
            // 
            panel5.Anchor = AnchorStyles.None;
            panel5.BackColor = Color.LightGray;
            panel5.Location = new Point(5, 80);
            panel5.Margin = new Padding(3, 4, 3, 4);
            panel5.Name = "panel5";
            panel5.Size = new Size(237, 1);
            panel5.TabIndex = 30;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = Color.Transparent;
            label14.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label14.ForeColor = Color.FromArgb(93, 62, 188);
            label14.Location = new Point(0, 0);
            label14.Name = "label14";
            label14.Size = new Size(48, 15);
            label14.TabIndex = 56;
            label14.Text = "Telefon";
            // 
            // maskedTextBox2
            // 
            maskedTextBox2.Location = new Point(9, 41);
            maskedTextBox2.Margin = new Padding(3, 4, 3, 4);
            maskedTextBox2.Mask = "(999) 000-0000";
            maskedTextBox2.Name = "maskedTextBox2";
            maskedTextBox2.Size = new Size(231, 21);
            maskedTextBox2.TabIndex = 22;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Transparent;
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(label15);
            panel1.Controls.Add(textBox1);
            panel1.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel1.ForeColor = Color.Transparent;
            panel1.Location = new Point(123, 187);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(248, 112);
            panel1.TabIndex = 60;
            // 
            // panel3
            // 
            panel3.Anchor = AnchorStyles.None;
            panel3.BackColor = Color.LightGray;
            panel3.Location = new Point(5, 79);
            panel3.Margin = new Padding(3, 4, 3, 4);
            panel3.Name = "panel3";
            panel3.Size = new Size(237, 1);
            panel3.TabIndex = 30;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.BackColor = Color.Transparent;
            label15.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label15.ForeColor = Color.FromArgb(93, 62, 188);
            label15.Location = new Point(0, 0);
            label15.Name = "label15";
            label15.Size = new Size(25, 15);
            label15.TabIndex = 56;
            label15.Text = "Adı";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(9, 40);
            textBox1.Margin = new Padding(3, 4, 3, 4);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(231, 21);
            textBox1.TabIndex = 1;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(93, 62, 188);
            button2.FlatAppearance.BorderColor = Color.FromArgb(93, 62, 188);
            button2.FlatAppearance.BorderSize = 2;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button2.ForeColor = Color.White;
            button2.Location = new Point(557, 629);
            button2.Margin = new Padding(3, 4, 3, 4);
            button2.Name = "button2";
            button2.Size = new Size(149, 47);
            button2.TabIndex = 18;
            button2.Text = "Personelleri Listele";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            button2.MouseEnter += button2_MouseEnter;
            button2.MouseLeave += button2_MouseLeave;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(93, 62, 188);
            button1.FlatAppearance.BorderColor = Color.FromArgb(93, 62, 188);
            button1.FlatAppearance.BorderSize = 2;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button1.ForeColor = Color.White;
            button1.Location = new Point(110, 629);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(128, 47);
            button1.TabIndex = 16;
            button1.Text = "Personel Ekle";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            button1.MouseEnter += button1_MouseEnter;
            button1.MouseLeave += button1_MouseLeave;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.FromArgb(93, 62, 188);
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.GridColor = SystemColors.ActiveBorder;
            dataGridView1.Location = new Point(114, 700);
            dataGridView1.Margin = new Padding(3, 4, 3, 4);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(582, 125);
            dataGridView1.TabIndex = 15;
            dataGridView1.CellMouseClick += dataGridView1_CellMouseClick;
            // 
            // personel
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(230, 225, 225);
            ClientSize = new Size(815, 851);
            Controls.Add(panel2);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "personel";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "personel";
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel14.ResumeLayout(false);
            panel14.PerformLayout();
            panel12.ResumeLayout(false);
            panel12.PerformLayout();
            panel16.ResumeLayout(false);
            panel16.PerformLayout();
            panel10.ResumeLayout(false);
            panel10.PerformLayout();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Panel panel2;
        private ComboBox comboBox2;
        private ComboBox comboBox1;
        private TextBox textBox4;
        private TextBox textBox2;
        private TextBox textBox1;
        private DataGridView dataGridView1;
        private Button button1;
        private TextBox textBox5;
        private Button button2;
        private MaskedTextBox maskedTextBox1;
        private MaskedTextBox maskedTextBox2;
        private TextBox textBox3;
        private Button button3;
        private Button button4;
        private Button button5;
        private Panel panel14;
        private Panel panel15;
        private Label label16;
        private Panel panel12;
        private Panel panel13;
        private Label label10;
        private Panel panel16;
        private Panel panel17;
        private Label label17;
        private Panel panel10;
        private Panel panel11;
        private Label label11;
        private Panel panel8;
        private Panel panel9;
        private Label label12;
        private Panel panel6;
        private Panel panel7;
        private Label label13;
        private Panel panel4;
        private Panel panel5;
        private Label label14;
        private Panel panel1;
        private Panel panel3;
        private Label label15;
        private Label label3;
        private Panel panel21;
        private Panel panel20;
        private Panel panel18;
        private Panel panel19;
        private PictureBox pictureBox1;
    }
}