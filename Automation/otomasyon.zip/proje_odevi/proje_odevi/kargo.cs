﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace proje_odevi
{
    public partial class kargo : Form
    {
        public kargo()
        {
            InitializeComponent();
        }

        // Veritabanı bağlantısı oluşturma  
        static string constring = "Data Source=FURKAN\\SQLEXPRESS;Initial Catalog=Nalbur_DB;Integrated Security=True;";
        SqlConnection baglanti = new SqlConnection(constring);

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        // Listele butonu için oluşturduğumuz veri tabanı kayıtlarını data grid view üzerinde gösterdiğimiz fonksiyonun oluşum kısmı
        public void kayitlari_goruntule()
        {


            string kayitlari_goruntule = "Select * From kargo1";

            SqlCommand goruntuleme_komutu = new SqlCommand(kayitlari_goruntule, baglanti);

            SqlDataAdapter Adapter = new SqlDataAdapter(goruntuleme_komutu);



            DataTable DataTable = new DataTable();
            Adapter.Fill(DataTable);
            dataGridView1.DataSource = DataTable;


        }

        private void button2_Click(object sender, EventArgs e)
        {
            kayitlari_goruntule();
        }

        // Yukarı kısımdaki arama çubuğu aracılığıyla arama yaptığımız fonksiyonun oluşum kısmı

        private void button1_Click(object sender, EventArgs e)
        {
            string kayitlari_ara = "Select * From Siparisler Where SiparisTarihi=@SiparisTarihi";

            SqlCommand arama_komutu = new SqlCommand(kayitlari_ara, baglanti);

            arama_komutu.Parameters.AddWithValue("@SiparisTarihi", textBox5.Text);


            SqlDataAdapter Adapter = new SqlDataAdapter(arama_komutu);

            DataTable DataTable = new DataTable();
            Adapter.Fill(DataTable);
            dataGridView1.DataSource = DataTable;

            baglanti.Close();
        }

        int sayac = 0;

        // Ekle butonu için veri tabanına ekleme yaptırdığımız fonksiyonun oluşum kısmı

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (baglanti.State == ConnectionState.Closed)
                {
                    baglanti.Open();

                    string ekleme = "insert into kargo1 (siparis_durumu,kargocu_personel,kargo_firması,tahmini_teslimat,personelin_telefonu,kargo_notu,kargo_id) values (@siparis_durumu,@kargocu_personel,@kargo_firması,@tahmini_teslimat,@personelin_telefonu,@kargo_notu,@kargo_id)";

                    SqlCommand ekleme_komutu = new SqlCommand(ekleme, baglanti);


                    ekleme_komutu.Parameters.AddWithValue("@kargocu_personel", comboBox1.SelectedItem);
                    ekleme_komutu.Parameters.AddWithValue("@kargo_firması", comboBox4.SelectedItem);
                    ekleme_komutu.Parameters.AddWithValue("@tahmini_teslimat", comboBox2.SelectedItem);
                    ekleme_komutu.Parameters.AddWithValue("@personelin_telefonu", textBox2.Text);
                    ekleme_komutu.Parameters.AddWithValue("@kargo_notu", textBox3.Text);
                    ekleme_komutu.Parameters.AddWithValue("@kargo_id", textBox1.Text);

                    ekleme_komutu.Parameters.AddWithValue("@siparis_durumu", comboBox3.SelectedItem);




                    ekleme_komutu.ExecuteNonQuery();

                    MessageBox.Show("Kargonuz Başarıyla Oluşturuldu.", "Kargo Oluşturma İşlemi");
                    kayitlari_goruntule();
                }


                else
                {

                }




            }
            catch (Exception hata)
            {
                MessageBox.Show("Hata: " + hata.Message);
            }


        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            sayac = e.RowIndex;

            comboBox3.Text = dataGridView1.Rows[sayac].Cells[5].Value.ToString();
            
        }

        // Bu kısımda kargocuların verilerini combo box 1 e çektirdiğimiz fonksiyonun oluşum kısmı

        private void kargo_Load(object sender, EventArgs e)
        {
            SqlCommand combo_boxa_veri_aktarma = new SqlCommand("Select * From Personel", baglanti);

            

            SqlDataReader cbva;

            



            baglanti.Open();



            cbva = combo_boxa_veri_aktarma.ExecuteReader();




            while (cbva.Read())
            {
                comboBox1.Items.Add(cbva["Adi"]);
            }

            baglanti.Close();






        }
    }

}
