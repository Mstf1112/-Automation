﻿namespace proje_odevi
{
    partial class kayit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(kayit));
            exit = new FontAwesome.Sharp.IconButton();
            minimize = new FontAwesome.Sharp.IconButton();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            maskedTextBox1 = new MaskedTextBox();
            maskedTextBox2 = new MaskedTextBox();
            maskedTextBox3 = new MaskedTextBox();
            maskedTextBox4 = new MaskedTextBox();
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            button1 = new Button();
            ıconButton1 = new FontAwesome.Sharp.IconButton();
            panel1 = new Panel();
            panel2 = new Panel();
            label2 = new Label();
            panel3 = new Panel();
            panel4 = new Panel();
            label1 = new Label();
            panel5 = new Panel();
            panel6 = new Panel();
            label3 = new Label();
            panel7 = new Panel();
            panel8 = new Panel();
            label4 = new Label();
            panel9 = new Panel();
            panel10 = new Panel();
            label9 = new Label();
            panel11 = new Panel();
            panel12 = new Panel();
            label7 = new Label();
            panel13 = new Panel();
            panel14 = new Panel();
            label6 = new Label();
            panel15 = new Panel();
            panel16 = new Panel();
            label5 = new Label();
            label10 = new Label();
            label11 = new Label();
            linkLabel1 = new LinkLabel();
            panel17 = new Panel();
            maskedTextBox5 = new MaskedTextBox();
            panel18 = new Panel();
            label8 = new Label();
            checkBox1 = new CheckBox();
            label12 = new Label();
            linkLabel2 = new LinkLabel();
            label13 = new Label();
            panel1.SuspendLayout();
            panel3.SuspendLayout();
            panel5.SuspendLayout();
            panel7.SuspendLayout();
            panel9.SuspendLayout();
            panel11.SuspendLayout();
            panel13.SuspendLayout();
            panel15.SuspendLayout();
            panel17.SuspendLayout();
            SuspendLayout();
            // 
            // exit
            // 
            exit.BackColor = Color.Transparent;
            exit.BackgroundImage = (Image)resources.GetObject("exit.BackgroundImage");
            exit.BackgroundImageLayout = ImageLayout.Zoom;
            exit.FlatAppearance.BorderSize = 0;
            exit.FlatStyle = FlatStyle.Flat;
            exit.ForeColor = SystemColors.ControlText;
            exit.IconChar = FontAwesome.Sharp.IconChar.None;
            exit.IconColor = Color.Black;
            exit.IconFont = FontAwesome.Sharp.IconFont.Auto;
            exit.Location = new Point(1134, 24);
            exit.Name = "exit";
            exit.Size = new Size(17, 17);
            exit.TabIndex = 26;
            exit.UseVisualStyleBackColor = false;
            exit.Click += exit_Click;
            // 
            // minimize
            // 
            minimize.BackColor = Color.Transparent;
            minimize.BackgroundImageLayout = ImageLayout.Zoom;
            minimize.FlatAppearance.BorderSize = 0;
            minimize.FlatStyle = FlatStyle.Flat;
            minimize.IconChar = FontAwesome.Sharp.IconChar.None;
            minimize.IconColor = Color.Black;
            minimize.IconFont = FontAwesome.Sharp.IconFont.Auto;
            minimize.Location = new Point(1081, 24);
            minimize.Name = "minimize";
            minimize.Size = new Size(17, 17);
            minimize.TabIndex = 25;
            minimize.UseVisualStyleBackColor = false;
            // 
            // textBox1
            // 
            textBox1.BackColor = SystemColors.Window;
            textBox1.ForeColor = Color.Gray;
            textBox1.Location = new Point(8, 32);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(287, 21);
            textBox1.TabIndex = 27;
            textBox1.Text = "Ad Girin";
            textBox1.MouseClick += textBox1_MouseClick;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // textBox2
            // 
            textBox2.BackColor = SystemColors.Window;
            textBox2.ForeColor = Color.Gray;
            textBox2.Location = new Point(8, 28);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(287, 21);
            textBox2.TabIndex = 28;
            textBox2.Text = "Soyad  Girin";
            textBox2.MouseClick += textBox2_MouseClick;
            // 
            // textBox3
            // 
            textBox3.ForeColor = Color.Gray;
            textBox3.Location = new Point(8, 26);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(287, 21);
            textBox3.TabIndex = 29;
            textBox3.Text = "İD Girin";
            textBox3.MouseClick += textBox3_MouseClick;
            // 
            // maskedTextBox1
            // 
            maskedTextBox1.ForeColor = Color.Gray;
            maskedTextBox1.Location = new Point(8, 27);
            maskedTextBox1.Mask = "(999) 000-0000";
            maskedTextBox1.Name = "maskedTextBox1";
            maskedTextBox1.Size = new Size(287, 21);
            maskedTextBox1.TabIndex = 30;
            maskedTextBox1.MouseClick += maskedTextBox1_MouseClick;
            // 
            // maskedTextBox2
            // 
            maskedTextBox2.ForeColor = Color.Gray;
            maskedTextBox2.Location = new Point(8, 27);
            maskedTextBox2.Name = "maskedTextBox2";
            maskedTextBox2.Size = new Size(287, 21);
            maskedTextBox2.TabIndex = 31;
            maskedTextBox2.Text = "Mail Girin";
            maskedTextBox2.MouseClick += maskedTextBox2_MouseClick;
            // 
            // maskedTextBox3
            // 
            maskedTextBox3.ForeColor = Color.Gray;
            maskedTextBox3.Location = new Point(8, 31);
            maskedTextBox3.Mask = "00/00/0000";
            maskedTextBox3.Name = "maskedTextBox3";
            maskedTextBox3.Size = new Size(287, 21);
            maskedTextBox3.TabIndex = 32;
            maskedTextBox3.ValidatingType = typeof(DateTime);
            maskedTextBox3.MouseClick += maskedTextBox3_MouseClick;
            // 
            // maskedTextBox4
            // 
            maskedTextBox4.ForeColor = Color.Gray;
            maskedTextBox4.Location = new Point(8, 27);
            maskedTextBox4.Mask = "99999999999";
            maskedTextBox4.Name = "maskedTextBox4";
            maskedTextBox4.Size = new Size(287, 21);
            maskedTextBox4.TabIndex = 33;
            maskedTextBox4.MouseClick += maskedTextBox4_MouseClick;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            radioButton1.ForeColor = Color.Black;
            radioButton1.Location = new Point(69, 55);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(56, 19);
            radioButton1.TabIndex = 41;
            radioButton1.TabStop = true;
            radioButton1.Text = "Erkek";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            radioButton2.ForeColor = Color.Black;
            radioButton2.Location = new Point(168, 55);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(57, 19);
            radioButton2.TabIndex = 42;
            radioButton2.TabStop = true;
            radioButton2.Text = "Kadın";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(93, 62, 188);
            button1.FlatAppearance.BorderColor = Color.FromArgb(93, 62, 188);
            button1.FlatAppearance.BorderSize = 2;
            button1.FlatAppearance.MouseDownBackColor = Color.Transparent;
            button1.FlatAppearance.MouseOverBackColor = Color.FromArgb(93, 62, 188);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            button1.ForeColor = Color.FromArgb(248, 247, 247);
            button1.Location = new Point(490, 421);
            button1.Name = "button1";
            button1.Size = new Size(200, 50);
            button1.TabIndex = 44;
            button1.Text = "Üye Ol";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            button1.MouseEnter += button1_MouseEnter;
            button1.MouseLeave += button1_MouseLeave;
            // 
            // ıconButton1
            // 
            ıconButton1.BackColor = Color.Transparent;
            ıconButton1.BackgroundImage = (Image)resources.GetObject("ıconButton1.BackgroundImage");
            ıconButton1.BackgroundImageLayout = ImageLayout.Zoom;
            ıconButton1.FlatAppearance.BorderSize = 0;
            ıconButton1.FlatStyle = FlatStyle.Flat;
            ıconButton1.IconChar = FontAwesome.Sharp.IconChar.None;
            ıconButton1.IconColor = Color.Black;
            ıconButton1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            ıconButton1.Location = new Point(1111, 24);
            ıconButton1.Name = "ıconButton1";
            ıconButton1.Size = new Size(17, 17);
            ıconButton1.TabIndex = 48;
            ıconButton1.UseVisualStyleBackColor = false;
            ıconButton1.Click += ıconButton1_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Transparent;
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(textBox1);
            panel1.Controls.Add(label2);
            panel1.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel1.ForeColor = Color.Transparent;
            panel1.Location = new Point(71, 157);
            panel1.Name = "panel1";
            panel1.Size = new Size(302, 84);
            panel1.TabIndex = 49;
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.None;
            panel2.BackColor = Color.LightGray;
            panel2.Location = new Point(8, 61);
            panel2.Name = "panel2";
            panel2.Size = new Size(287, 1);
            panel2.TabIndex = 30;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.FromArgb(93, 62, 188);
            label2.Location = new Point(0, 0);
            label2.Name = "label2";
            label2.Size = new Size(22, 15);
            label2.TabIndex = 56;
            label2.Text = "Ad";
            // 
            // panel3
            // 
            panel3.BackColor = Color.Transparent;
            panel3.Controls.Add(panel4);
            panel3.Controls.Add(textBox2);
            panel3.Controls.Add(label1);
            panel3.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel3.ForeColor = Color.Transparent;
            panel3.Location = new Point(71, 241);
            panel3.Name = "panel3";
            panel3.Size = new Size(302, 84);
            panel3.TabIndex = 50;
            // 
            // panel4
            // 
            panel4.Anchor = AnchorStyles.None;
            panel4.BackColor = Color.LightGray;
            panel4.Location = new Point(8, 57);
            panel4.Name = "panel4";
            panel4.Size = new Size(287, 1);
            panel4.TabIndex = 30;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.FromArgb(93, 62, 188);
            label1.Location = new Point(0, 0);
            label1.Name = "label1";
            label1.Size = new Size(42, 15);
            label1.TabIndex = 58;
            label1.Text = "Soyad";
            // 
            // panel5
            // 
            panel5.BackColor = Color.Transparent;
            panel5.Controls.Add(panel6);
            panel5.Controls.Add(maskedTextBox1);
            panel5.Controls.Add(label3);
            panel5.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel5.ForeColor = Color.Transparent;
            panel5.Location = new Point(71, 325);
            panel5.Name = "panel5";
            panel5.Size = new Size(302, 84);
            panel5.TabIndex = 51;
            panel5.Paint += panel5_Paint;
            // 
            // panel6
            // 
            panel6.Anchor = AnchorStyles.None;
            panel6.BackColor = Color.LightGray;
            panel6.Location = new Point(8, 56);
            panel6.Name = "panel6";
            panel6.Size = new Size(287, 1);
            panel6.TabIndex = 30;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.FromArgb(93, 62, 188);
            label3.Location = new Point(0, 0);
            label3.Name = "label3";
            label3.Size = new Size(48, 15);
            label3.TabIndex = 60;
            label3.Text = "Telefon";
            // 
            // panel7
            // 
            panel7.BackColor = Color.Transparent;
            panel7.Controls.Add(panel8);
            panel7.Controls.Add(maskedTextBox2);
            panel7.Controls.Add(label4);
            panel7.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel7.ForeColor = Color.Transparent;
            panel7.Location = new Point(71, 409);
            panel7.Name = "panel7";
            panel7.Size = new Size(302, 84);
            panel7.TabIndex = 52;
            // 
            // panel8
            // 
            panel8.Anchor = AnchorStyles.None;
            panel8.BackColor = Color.LightGray;
            panel8.Location = new Point(8, 56);
            panel8.Name = "panel8";
            panel8.Size = new Size(287, 1);
            panel8.TabIndex = 30;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.FromArgb(93, 62, 188);
            label4.Location = new Point(0, 0);
            label4.Name = "label4";
            label4.Size = new Size(38, 15);
            label4.TabIndex = 62;
            label4.Text = "Email";
            // 
            // panel9
            // 
            panel9.BackColor = Color.Transparent;
            panel9.Controls.Add(panel10);
            panel9.Controls.Add(maskedTextBox3);
            panel9.Controls.Add(label9);
            panel9.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel9.ForeColor = Color.Transparent;
            panel9.Location = new Point(798, 157);
            panel9.Name = "panel9";
            panel9.Size = new Size(302, 84);
            panel9.TabIndex = 53;
            // 
            // panel10
            // 
            panel10.Anchor = AnchorStyles.None;
            panel10.BackColor = Color.LightGray;
            panel10.Location = new Point(8, 60);
            panel10.Name = "panel10";
            panel10.Size = new Size(287, 1);
            panel10.TabIndex = 30;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label9.ForeColor = Color.FromArgb(93, 62, 188);
            label9.Location = new Point(0, 0);
            label9.Name = "label9";
            label9.Size = new Size(81, 15);
            label9.TabIndex = 64;
            label9.Text = "Doğum Tarihi";
            // 
            // panel11
            // 
            panel11.BackColor = Color.Transparent;
            panel11.Controls.Add(panel12);
            panel11.Controls.Add(maskedTextBox4);
            panel11.Controls.Add(label7);
            panel11.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel11.ForeColor = Color.Transparent;
            panel11.Location = new Point(798, 241);
            panel11.Name = "panel11";
            panel11.Size = new Size(302, 84);
            panel11.TabIndex = 53;
            panel11.Paint += panel11_Paint;
            // 
            // panel12
            // 
            panel12.Anchor = AnchorStyles.None;
            panel12.BackColor = Color.LightGray;
            panel12.Location = new Point(8, 56);
            panel12.Name = "panel12";
            panel12.Size = new Size(287, 1);
            panel12.TabIndex = 30;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label7.ForeColor = Color.FromArgb(93, 62, 188);
            label7.Location = new Point(0, 0);
            label7.Name = "label7";
            label7.Size = new Size(22, 15);
            label7.TabIndex = 66;
            label7.Text = "TC";
            label7.Click += label7_Click;
            // 
            // panel13
            // 
            panel13.BackColor = Color.Transparent;
            panel13.Controls.Add(panel14);
            panel13.Controls.Add(textBox3);
            panel13.Controls.Add(label6);
            panel13.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel13.ForeColor = Color.Transparent;
            panel13.Location = new Point(798, 326);
            panel13.Name = "panel13";
            panel13.Size = new Size(302, 84);
            panel13.TabIndex = 54;
            // 
            // panel14
            // 
            panel14.Anchor = AnchorStyles.None;
            panel14.BackColor = Color.LightGray;
            panel14.Location = new Point(8, 55);
            panel14.Name = "panel14";
            panel14.Size = new Size(287, 1);
            panel14.TabIndex = 30;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.FromArgb(93, 62, 188);
            label6.Location = new Point(0, 0);
            label6.Name = "label6";
            label6.Size = new Size(18, 15);
            label6.TabIndex = 68;
            label6.Text = "İD";
            // 
            // panel15
            // 
            panel15.BackColor = Color.Transparent;
            panel15.Controls.Add(panel16);
            panel15.Controls.Add(radioButton2);
            panel15.Controls.Add(label5);
            panel15.Controls.Add(radioButton1);
            panel15.ForeColor = Color.Transparent;
            panel15.Location = new Point(798, 410);
            panel15.Name = "panel15";
            panel15.Size = new Size(302, 84);
            panel15.TabIndex = 55;
            // 
            // panel16
            // 
            panel16.Anchor = AnchorStyles.None;
            panel16.BackColor = Color.LightGray;
            panel16.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel16.Location = new Point(8, 45);
            panel16.Name = "panel16";
            panel16.Size = new Size(287, 1);
            panel16.TabIndex = 30;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = Color.FromArgb(93, 62, 188);
            label5.Location = new Point(122, 17);
            label5.Name = "label5";
            label5.Size = new Size(52, 15);
            label5.TabIndex = 70;
            label5.Text = "Cinsiyet";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label10.ForeColor = Color.FromArgb(93, 62, 188);
            label10.Location = new Point(532, 89);
            label10.Name = "label10";
            label10.Size = new Size(104, 24);
            label10.TabIndex = 72;
            label10.Text = "KAYIT OL";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(500, 482);
            label11.Name = "label11";
            label11.Size = new Size(145, 15);
            label11.TabIndex = 73;
            label11.Text = "Hesabın Varmı ? Hemen ";
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.LinkColor = Color.FromArgb(93, 62, 188);
            linkLabel1.Location = new Point(642, 482);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(55, 15);
            linkLabel1.TabIndex = 74;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Giriş Yap.";
            linkLabel1.LinkClicked += linkLabel1_LinkClicked;
            // 
            // panel17
            // 
            panel17.BackColor = Color.Transparent;
            panel17.Controls.Add(maskedTextBox5);
            panel17.Controls.Add(panel18);
            panel17.Controls.Add(label8);
            panel17.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel17.ForeColor = Color.Transparent;
            panel17.Location = new Point(438, 188);
            panel17.Name = "panel17";
            panel17.Size = new Size(302, 84);
            panel17.TabIndex = 57;
            panel17.Paint += panel17_Paint;
            // 
            // maskedTextBox5
            // 
            maskedTextBox5.AccessibleDescription = "";
            maskedTextBox5.ForeColor = Color.Gray;
            maskedTextBox5.Location = new Point(6, 31);
            maskedTextBox5.Mask = "aaaaaaaaaaaa";
            maskedTextBox5.Name = "maskedTextBox5";
            maskedTextBox5.PasswordChar = '*';
            maskedTextBox5.Size = new Size(287, 21);
            maskedTextBox5.TabIndex = 61;
            maskedTextBox5.MouseClick += maskedTextBox5_MouseClick;
            // 
            // panel18
            // 
            panel18.Anchor = AnchorStyles.None;
            panel18.BackColor = Color.LightGray;
            panel18.Location = new Point(6, 61);
            panel18.Name = "panel18";
            panel18.Size = new Size(287, 1);
            panel18.TabIndex = 30;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = Color.FromArgb(93, 62, 188);
            label8.Location = new Point(0, 0);
            label8.Name = "label8";
            label8.Size = new Size(34, 15);
            label8.TabIndex = 56;
            label8.Text = "Şifre";
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(438, 299);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(116, 19);
            checkBox1.TabIndex = 75;
            checkBox1.Text = "Üye Ol'a Basarak ";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(642, 300);
            label12.Name = "label12";
            label12.Size = new Size(94, 15);
            label12.TabIndex = 76;
            label12.Text = "Kabul Ediyorum.";
            label12.Click += label12_Click;
            // 
            // linkLabel2
            // 
            linkLabel2.AutoSize = true;
            linkLabel2.LinkColor = Color.FromArgb(93, 62, 188);
            linkLabel2.Location = new Point(547, 299);
            linkLabel2.Name = "linkLabel2";
            linkLabel2.Size = new Size(97, 15);
            linkLabel2.TabIndex = 77;
            linkLabel2.TabStop = true;
            linkLabel2.Text = "Üyelik Koşullarını";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(461, 257);
            label13.Name = "label13";
            label13.Size = new Size(239, 15);
            label13.TabIndex = 78;
            label13.Text = "Şifre En Az 1 En Fazla 12 Karakter İçermelidir.";
            // 
            // kayit
            // 
            AccessibleDescription = "*";
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(248, 247, 247);
            ClientSize = new Size(1174, 599);
            Controls.Add(label13);
            Controls.Add(linkLabel2);
            Controls.Add(label12);
            Controls.Add(checkBox1);
            Controls.Add(panel17);
            Controls.Add(linkLabel1);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(panel15);
            Controls.Add(panel13);
            Controls.Add(panel11);
            Controls.Add(panel9);
            Controls.Add(panel7);
            Controls.Add(panel5);
            Controls.Add(panel3);
            Controls.Add(panel1);
            Controls.Add(ıconButton1);
            Controls.Add(button1);
            Controls.Add(exit);
            Controls.Add(minimize);
            FormBorderStyle = FormBorderStyle.None;
            Name = "kayit";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "kayit";
            Load += kayit_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel9.ResumeLayout(false);
            panel9.PerformLayout();
            panel11.ResumeLayout(false);
            panel11.PerformLayout();
            panel13.ResumeLayout(false);
            panel13.PerformLayout();
            panel15.ResumeLayout(false);
            panel15.PerformLayout();
            panel17.ResumeLayout(false);
            panel17.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private FontAwesome.Sharp.IconButton exit;
        private FontAwesome.Sharp.IconButton minimize;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private MaskedTextBox maskedTextBox1;
        private MaskedTextBox maskedTextBox2;
        private MaskedTextBox maskedTextBox3;
        private MaskedTextBox maskedTextBox4;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private Button button1;
        private FontAwesome.Sharp.IconButton ıconButton1;
        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Panel panel4;
        private Panel panel5;
        private Panel panel6;
        private Panel panel7;
        private Panel panel8;
        private Panel panel9;
        private Panel panel10;
        private Panel panel11;
        private Panel panel12;
        private Panel panel13;
        private Panel panel14;
        private Panel panel15;
        private Panel panel16;
        private Label label9;
        private Label label10;
        private Label label11;
        private LinkLabel linkLabel1;
        private Panel panel17;
        private Panel panel18;
        private Label label8;
        private CheckBox checkBox1;
        private Label label12;
        private LinkLabel linkLabel2;
        private MaskedTextBox maskedTextBox5;
        private Label label13;
    }
}