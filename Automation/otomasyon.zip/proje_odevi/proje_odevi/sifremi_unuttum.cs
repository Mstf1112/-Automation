﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace proje_odevi
{
    public partial class sifremi_unuttum : Form
    {
        public sifremi_unuttum()
        {
            InitializeComponent();
        }

        // Veritabanı bağlantısı oluşturma  

        static string constring = "Data Source=FURKAN\\SQLEXPRESS;Initial Catalog=giris_ekrani;Integrated Security=True;";
        SqlConnection baglanti = new SqlConnection(constring);

        private void exit_Click(object sender, EventArgs e)
        {
            giris_ekrani Kayit_Ekrani = new giris_ekrani();
            Kayit_Ekrani.Show();
            this.Hide();
        }

        private void minimize_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        // Veritabanına daha önceden girili olan bilgilerinin etkileşiminin oluşturulduğu kısım , eğer kayıt kısmındaki bilgilerinizi hatırlıyorsanız ve giris bilgilerini
        // unuttuysanız bu kısımdan rahatça tekrardan geri alabilirsiniz

        private void button1_Click(object sender, EventArgs e)
        {
            String email, tc;

            email = textBox1.Text;
            tc = maskedTextBox1.Text;

            try
            {

                string giris = "select * from Kullanici where Mail = '" + textBox1.Text + "' and Tc = '" + maskedTextBox1.Text + "'";
                SqlDataAdapter giris_komutu = new SqlDataAdapter(giris, baglanti);

                DataTable DataTable = new DataTable();
                giris_komutu.Fill(DataTable);

                if (DataTable.Rows.Count > 0)
                {

                    MessageBox.Show("Doğrulama Bilgileriniz Onaylandı. Şifre Yenileme Ekranına Yönlendiriliyorsunuz.", "Doğruluma Başarılı!", MessageBoxButtons.OK, MessageBoxIcon.Information);


                    sifremi_unuttum2 sifre_yenile = new sifremi_unuttum2();
                    sifre_yenile.Show();
                    this.Hide();
                }

                else
                {
                    textBox1.ForeColor = Color.Black;


                    maskedTextBox1.ForeColor = Color.Black;
                    panel4.Visible = true;


                    textBox1.Clear();
                    maskedTextBox1.Clear();

                    textBox1.Focus();


                }

                baglanti.Close();
            }

            catch
            {
                MessageBox.Show("hata");


            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void textBox1_MouseClick(object sender, MouseEventArgs e)
        {
            textBox1.SelectAll();
        }

        private void maskedTextBox1_MouseClick(object sender, MouseEventArgs e)
        {
            maskedTextBox1.SelectAll();
        }
    }
}
