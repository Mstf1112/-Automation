﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace proje_odevi
{
    public partial class personel : Form
    {
        public personel()
        {
            InitializeComponent();
        }

        // Veritabanı bağlantısı oluşturma  

        static string constring = "Data Source=FURKAN\\SQLEXPRESS;Initial Catalog=Nalbur_DB;Integrated Security=True;";
        SqlConnection baglanti = new SqlConnection(constring);

        // Listele butonu için oluşturduğumuz veri tabanı kayıtlarını data grid view üzerinde gösterdiğimiz fonksiyonun oluşum kısmı

        public void kayitlari_goruntule()
        {


            string kayitlari_goruntule = "Select * From Personel";

            SqlCommand goruntuleme_komutu = new SqlCommand(kayitlari_goruntule, baglanti);

            SqlDataAdapter Adapter = new SqlDataAdapter(goruntuleme_komutu);

            DataTable DataTable = new DataTable();
            Adapter.Fill(DataTable);
            dataGridView1.DataSource = DataTable;

            baglanti.Close();
        }

        // Sil butonu için oluşturduğumuz veri tabanı kayıtlarını silen fonksiyonun oluşum kısmı

        public void kayitlari_sil(int PersonelID)
        {


            string kayitlari_sil = "Delete From Personel Where PersonelID=@PersonelID";

            SqlCommand silme_komutu = new SqlCommand(kayitlari_sil, baglanti);


            baglanti.Open();

            silme_komutu.Parameters.AddWithValue("@PersonelID", PersonelID);

            silme_komutu.ExecuteNonQuery();



            baglanti.Close();
        }

        // Ekle butonu için veri tabanına ekleme yaptırdığımız fonksiyonun oluşum kısmı

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (baglanti.State == ConnectionState.Closed)
                {
                    baglanti.Open();

                    string kaydetme = "insert into Personel (Adi, Soyadi, Telefon, Maas, izingunu, Pozisyon,iseGirisTarihi, PersonelID) values(@Adi, @Soyadi, @Telefon, @Maas, @izingunu, @Pozisyon,@iseGirisTarihi, @PersonelID)";


                    SqlCommand kaydetme_komutu = new SqlCommand(kaydetme, baglanti);

                    kaydetme_komutu.Parameters.AddWithValue("@Adi", textBox1.Text);
                    kaydetme_komutu.Parameters.AddWithValue("@Soyadi", textBox2.Text);
                    kaydetme_komutu.Parameters.AddWithValue("@Telefon", maskedTextBox2.Text);
                    kaydetme_komutu.Parameters.AddWithValue("@Maas", textBox4.Text);
                    kaydetme_komutu.Parameters.AddWithValue("@izingunu", comboBox1.SelectedItem);
                    kaydetme_komutu.Parameters.AddWithValue("@Pozisyon", comboBox2.SelectedItem);
                    kaydetme_komutu.Parameters.AddWithValue("@iseGirisTarihi", maskedTextBox1.Text);
                    kaydetme_komutu.Parameters.AddWithValue("@PersonelID", textBox5.Text);



                    kaydetme_komutu.ExecuteNonQuery();

                    MessageBox.Show("Personel Kaydınız Başarıyla Eklendi.", "Kayıt İşlemi");
                }
            }

            catch (Exception kaydedilmedi)
            {

                MessageBox.Show("Kayıt Eklenemedi.", kaydedilmedi.Message);

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            kayitlari_goruntule();
        }

        // Yukarı kısımdaki arama çubuğu aracılığıyla arama yaptığımız fonksiyonun oluşum kısmı

        private void button3_Click(object sender, EventArgs e)
        {
            string kayitlari_ara = "Select * From Personel Where Adi=@Adi";

            SqlCommand arama_komutu = new SqlCommand(kayitlari_ara, baglanti);

            arama_komutu.Parameters.AddWithValue("@Adi", textBox3.Text);


            SqlDataAdapter Adapter = new SqlDataAdapter(arama_komutu);

            DataTable DataTable = new DataTable();
            Adapter.Fill(DataTable);
            dataGridView1.DataSource = DataTable;

            baglanti.Close();
        }

        // Lisme işlemi kullanılırken id üzerinden yaptırdığımız işlemin fonksiyonunu oluşturduğumuz kısım

        private void button4_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow drow in dataGridView1.SelectedRows)
            {
                int PersonelID = Convert.ToInt32(drow.Cells[0].Value);
                kayitlari_sil(PersonelID);
                kayitlari_goruntule();
            }
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            sayac = e.RowIndex;

            textBox1.Text = dataGridView1.Rows[sayac].Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.Rows[sayac].Cells[2].Value.ToString();
            maskedTextBox2.Text = dataGridView1.Rows[sayac].Cells[3].Value.ToString();
            textBox4.Text = dataGridView1.Rows[sayac].Cells[4].Value.ToString();

            comboBox2.Text = dataGridView1.Rows[sayac].Cells[6].Value.ToString();
            comboBox1.Text = dataGridView1.Rows[sayac].Cells[5].Value.ToString();

            maskedTextBox1.Text = dataGridView1.Rows[sayac].Cells[7].Value.ToString();
        }


        // Güncelleme butonu için veri tabanı üzerinden verileri güncellediğimiz fonksiyonu oluşturduğumuz kısım


        int sayac = 0;

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {


                if (baglanti.State == ConnectionState.Closed)
                {
                    baglanti.Open();

                    string güncelleme = "UPDATE Personel SET Adi=@Adi, Soyadi=@Soyadi, Telefon=@Telefon, Maas=@Maas, izingunu=@izingunu, Pozisyon=@Pozisyon, iseGirisTarihi=@iseGirisTarihi WHERE PersonelID=@PersonelID";

                    SqlCommand güncelleme_komutu = new SqlCommand(güncelleme, baglanti);

                    güncelleme_komutu.Parameters.AddWithValue("@Adi", textBox1.Text);
                    güncelleme_komutu.Parameters.AddWithValue("@Soyadi", textBox2.Text);
                    güncelleme_komutu.Parameters.AddWithValue("@Telefon", maskedTextBox2.Text);
                    güncelleme_komutu.Parameters.AddWithValue("@Maas", textBox4.Text);
                    güncelleme_komutu.Parameters.AddWithValue("@izingunu", comboBox1.Text);
                    güncelleme_komutu.Parameters.AddWithValue("@Pozisyon", comboBox2.Text);
                    güncelleme_komutu.Parameters.AddWithValue("@iseGirisTarihi", maskedTextBox1.Text);
                    güncelleme_komutu.Parameters.AddWithValue("@PersonelID", dataGridView1.Rows[sayac].Cells["PersonelID"].Value);

                    güncelleme_komutu.ExecuteNonQuery();

                    MessageBox.Show("Ürün Kaydınız Başarıyla Güncellendi.", "Güncelleme İşlemi");
                    kayitlari_goruntule();
                }

            }

            catch (Exception hata)
            {
                MessageBox.Show("Güncelleme Hatası: " + hata.Message);
            }
        }

        private void panel2_MouseEnter(object sender, EventArgs e)
        {

        }

        private void panel2_MouseLeave(object sender, EventArgs e)
        {

        }

        // Buton efektlerini oluşturduğumuz kısım

        private void button2_MouseEnter(object sender, EventArgs e)
        {
            button2.BackColor = Color.FromArgb(93, 62, 188);
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            button2.BackColor = Color.FromArgb(93, 62, 188);
        }

        private void button5_MouseEnter(object sender, EventArgs e)
        {
            button5.BackColor = Color.FromArgb(93, 62, 188);
        }

        private void button5_MouseLeave(object sender, EventArgs e)
        {
            button5.BackColor = Color.FromArgb(93, 62, 188);
        }

        private void button4_MouseEnter(object sender, EventArgs e)
        {
            button4.BackColor = Color.FromArgb(93, 62, 188);
        }

        private void button4_MouseLeave(object sender, EventArgs e)
        {
            button4.BackColor = Color.FromArgb(93, 62, 188);
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(93, 62, 188);
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(93, 62, 188);
        }

        private void button3_MouseEnter(object sender, EventArgs e)
        {
            button3.BackColor = Color.FromArgb(93, 62, 188);
        }

        private void button3_MouseLeave(object sender, EventArgs e)
        {
            button3.BackColor = Color.FromArgb(93, 62, 188);
        }
    }

}
