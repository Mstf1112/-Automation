﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace proje_odevi
{
    public partial class giris_ekrani : Form
    {
        public giris_ekrani()
        {
            InitializeComponent();
        }

        // Veritabanı bağlantısı oluşturma  

        static string constring = "Data Source=FURKAN\\SQLEXPRESS;Initial Catalog=giris_ekrani;Integrated Security=True;";
        SqlConnection baglanti = new SqlConnection(constring);

        private void exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void minimize_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        // Veritabanımıza kayıtlı olan veriler ile alt tarafta oluşturmuş olduğumuz giriş sorgusunun kısmı

        private void button1_Click(object sender, EventArgs e)
        {


            String email, sifre;

            email = textBox1.Text;
            sifre = textBox2.Text;

            try
            {

                string giris = "select * from Kullanici where Mail = '" + textBox1.Text + "' and Sifre = '" + textBox2.Text + "'";
                SqlDataAdapter giris_komutu = new SqlDataAdapter(giris, baglanti);

                DataTable DataTable = new DataTable();
                giris_komutu.Fill(DataTable);

                if (DataTable.Rows.Count > 0)
                {

                    MessageBox.Show("Giriş Bilgileriniz Onaylandı. Mağazanıza Yönlendiriliyorsunuz.", "Giriş Başarılı!", MessageBoxButtons.OK, MessageBoxIcon.Information);


                    loading Yukleme_Ekrani = new loading();
                    Yukleme_Ekrani.Show();
                    this.Hide();
                }

                else
                {
                    textBox1.ForeColor = Color.Black;


                    textBox2.ForeColor = Color.Black;
                    panel4.Visible = true;


                    textBox1.Clear();
                    textBox2.Clear();

                    textBox1.Focus();


                }

                baglanti.Close();
            }

            catch
            {
                MessageBox.Show("hata");


            }

        }

        private void giris_ekrani_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }




        private void textBox1_MouseClick(object sender, MouseEventArgs e)
        {
            textBox1.SelectAll();
        }

        private void textBox2_MouseClick(object sender, MouseEventArgs e)
        {
            textBox2.SelectAll();
        }

        private void textBox2_MouseClick_1(object sender, MouseEventArgs e)
        {
            textBox2.SelectAll();
        }


        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }



        private void button2_Click(object sender, EventArgs e)
        {
            urunler Urunler = new urunler();
            Urunler.Show();
            this.Hide();
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            kayit Kayit_Ekrani = new kayit();
            Kayit_Ekrani.Show();
            this.Hide();
        }
        
        // Buton Efektleri

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(120, 73, 247);
        }

        // Buton Efektleri
        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(93, 62, 188);
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            sifremi_unuttum Dogrulama_Ekrani = new sifremi_unuttum();
            Dogrulama_Ekrani.Show();
            this.Hide();
        }
    }
}
