﻿namespace proje_odevi
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            panel2 = new Panel();
            personel = new FontAwesome.Sharp.IconButton();
            kargo = new FontAwesome.Sharp.IconButton();
            satislar = new FontAwesome.Sharp.IconButton();
            urunler = new FontAwesome.Sharp.IconButton();
            panel6 = new Panel();
            pictureBox3 = new PictureBox();
            panel1 = new Panel();
            panel4 = new Panel();
            exit = new FontAwesome.Sharp.IconButton();
            minimize = new FontAwesome.Sharp.IconButton();
            label12 = new Label();
            label11 = new Label();
            label7 = new Label();
            label3 = new Label();
            label2 = new Label();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            pictureBox2 = new PictureBox();
            panel18 = new Panel();
            panel17 = new Panel();
            timer1 = new System.Windows.Forms.Timer(components);
            panel2.SuspendLayout();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel17.SuspendLayout();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(247, 247, 247);
            panel2.Controls.Add(personel);
            panel2.Controls.Add(kargo);
            panel2.Controls.Add(satislar);
            panel2.Controls.Add(urunler);
            panel2.Controls.Add(panel6);
            panel2.Dock = DockStyle.Left;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(220, 638);
            panel2.TabIndex = 1;
            panel2.Paint += panel2_Paint;
            // 
            // personel
            // 
            personel.Dock = DockStyle.Top;
            personel.FlatAppearance.BorderSize = 0;
            personel.FlatStyle = FlatStyle.Flat;
            personel.Font = new Font("Arial", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            personel.ForeColor = Color.FromArgb(137, 75, 246);
            personel.IconChar = FontAwesome.Sharp.IconChar.None;
            personel.IconColor = Color.Black;
            personel.IconFont = FontAwesome.Sharp.IconFont.Auto;
            personel.Location = new Point(0, 355);
            personel.Name = "personel";
            personel.Size = new Size(220, 70);
            personel.TabIndex = 8;
            personel.Text = "Personel";
            personel.UseVisualStyleBackColor = true;
            personel.Click += personel_Click;
            // 
            // kargo
            // 
            kargo.Dock = DockStyle.Top;
            kargo.FlatAppearance.BorderSize = 0;
            kargo.FlatStyle = FlatStyle.Flat;
            kargo.Font = new Font("Arial", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            kargo.ForeColor = Color.FromArgb(137, 75, 246);
            kargo.IconChar = FontAwesome.Sharp.IconChar.None;
            kargo.IconColor = Color.Black;
            kargo.IconFont = FontAwesome.Sharp.IconFont.Auto;
            kargo.Location = new Point(0, 285);
            kargo.Name = "kargo";
            kargo.Size = new Size(220, 70);
            kargo.TabIndex = 7;
            kargo.Text = "Kargo";
            kargo.UseVisualStyleBackColor = true;
            kargo.Click += kargo_Click;
            // 
            // satislar
            // 
            satislar.BackColor = Color.Transparent;
            satislar.Dock = DockStyle.Top;
            satislar.FlatAppearance.BorderSize = 0;
            satislar.FlatStyle = FlatStyle.Flat;
            satislar.Font = new Font("Arial", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            satislar.ForeColor = Color.FromArgb(137, 75, 246);
            satislar.IconChar = FontAwesome.Sharp.IconChar.None;
            satislar.IconColor = Color.Black;
            satislar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            satislar.Location = new Point(0, 215);
            satislar.Name = "satislar";
            satislar.Size = new Size(220, 70);
            satislar.TabIndex = 6;
            satislar.Text = "Satışlar";
            satislar.UseVisualStyleBackColor = false;
            satislar.Click += satislar_Click;
            // 
            // urunler
            // 
            urunler.Dock = DockStyle.Top;
            urunler.FlatAppearance.BorderSize = 0;
            urunler.FlatStyle = FlatStyle.Flat;
            urunler.Font = new Font("Arial", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            urunler.ForeColor = Color.FromArgb(137, 75, 246);
            urunler.IconChar = FontAwesome.Sharp.IconChar.None;
            urunler.IconColor = Color.Black;
            urunler.IconFont = FontAwesome.Sharp.IconFont.Auto;
            urunler.Location = new Point(0, 145);
            urunler.Name = "urunler";
            urunler.Size = new Size(220, 70);
            urunler.TabIndex = 5;
            urunler.Text = "Ürünler";
            urunler.UseVisualStyleBackColor = true;
            urunler.Click += urunler_Click;
            // 
            // panel6
            // 
            panel6.Controls.Add(pictureBox3);
            panel6.Dock = DockStyle.Top;
            panel6.Location = new Point(0, 0);
            panel6.Name = "panel6";
            panel6.Size = new Size(220, 145);
            panel6.TabIndex = 4;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(21, 44);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(179, 83);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 0;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click_1;
            // 
            // panel1
            // 
            panel1.BackColor = Color.LightGray;
            panel1.Location = new Point(6, 22);
            panel1.Name = "panel1";
            panel1.Size = new Size(1, 600);
            panel1.TabIndex = 32;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(247, 247, 247);
            panel4.Controls.Add(exit);
            panel4.Controls.Add(minimize);
            panel4.Controls.Add(label12);
            panel4.Controls.Add(label11);
            panel4.Controls.Add(label7);
            panel4.Controls.Add(label3);
            panel4.Controls.Add(label2);
            panel4.Controls.Add(pictureBox1);
            panel4.Controls.Add(label1);
            panel4.Controls.Add(pictureBox2);
            panel4.Dock = DockStyle.Right;
            panel4.Location = new Point(933, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(273, 638);
            panel4.TabIndex = 2;
            // 
            // exit
            // 
            exit.BackColor = Color.Transparent;
            exit.BackgroundImage = (Image)resources.GetObject("exit.BackgroundImage");
            exit.BackgroundImageLayout = ImageLayout.Zoom;
            exit.FlatAppearance.BorderSize = 0;
            exit.FlatStyle = FlatStyle.Flat;
            exit.ForeColor = SystemColors.ControlText;
            exit.IconChar = FontAwesome.Sharp.IconChar.None;
            exit.IconColor = Color.Black;
            exit.IconFont = FontAwesome.Sharp.IconFont.Auto;
            exit.Location = new Point(229, 22);
            exit.Name = "exit";
            exit.Size = new Size(17, 17);
            exit.TabIndex = 21;
            exit.UseVisualStyleBackColor = false;
            exit.Click += exit_Click;
            // 
            // minimize
            // 
            minimize.BackColor = Color.Transparent;
            minimize.BackgroundImage = (Image)resources.GetObject("minimize.BackgroundImage");
            minimize.BackgroundImageLayout = ImageLayout.Zoom;
            minimize.FlatAppearance.BorderSize = 0;
            minimize.FlatStyle = FlatStyle.Flat;
            minimize.IconChar = FontAwesome.Sharp.IconChar.None;
            minimize.IconColor = Color.Black;
            minimize.IconFont = FontAwesome.Sharp.IconFont.Auto;
            minimize.Location = new Point(204, 22);
            minimize.Name = "minimize";
            minimize.Size = new Size(17, 17);
            minimize.TabIndex = 20;
            minimize.UseVisualStyleBackColor = false;
            minimize.Click += minimize_Click;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Arial", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label12.ForeColor = Color.FromArgb(137, 75, 246);
            label12.Location = new Point(42, 382);
            label12.Name = "label12";
            label12.Size = new Size(186, 16);
            label12.TabIndex = 17;
            label12.Text = "Kalan süre: saat dakika saniye";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label11.ForeColor = Color.Black;
            label11.Location = new Point(60, 342);
            label11.Name = "label11";
            label11.Size = new Size(168, 16);
            label11.TabIndex = 16;
            label11.Text = "Mağazanın Kapanmasına";
            label11.Click += label11_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.FromArgb(137, 75, 246);
            label7.Location = new Point(42, 455);
            label7.Name = "label7";
            label7.Size = new Size(192, 16);
            label7.TabIndex = 12;
            label7.Text = "Bugün sipariş bulunmamaktadır.";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.Black;
            label3.Location = new Point(95, 428);
            label3.Name = "label3";
            label3.Size = new Size(91, 16);
            label3.TabIndex = 8;
            label3.Text = "Günlük Satış ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.FromArgb(137, 75, 246);
            label2.Location = new Point(81, 275);
            label2.Name = "label2";
            label2.Size = new Size(132, 16);
            label2.TabIndex = 7;
            label2.Text = "Furkan YURTSEVEN";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(78, 122);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(139, 120);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 3;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(31, 69);
            label1.Name = "label1";
            label1.Size = new Size(60, 19);
            label1.TabIndex = 6;
            label1.Text = "SATICI";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(218, 69);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(28, 23);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 3;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // panel18
            // 
            panel18.BackColor = Color.LightGray;
            panel18.Location = new Point(706, 22);
            panel18.Name = "panel18";
            panel18.Size = new Size(1, 600);
            panel18.TabIndex = 31;
            // 
            // panel17
            // 
            panel17.BackColor = Color.FromArgb(247, 247, 247);
            panel17.Controls.Add(panel18);
            panel17.Controls.Add(panel1);
            panel17.Dock = DockStyle.Top;
            panel17.Location = new Point(220, 0);
            panel17.Name = "panel17";
            panel17.Size = new Size(713, 638);
            panel17.TabIndex = 3;
            panel17.Paint += panel17_Paint;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1206, 638);
            Controls.Add(panel17);
            Controls.Add(panel4);
            Controls.Add(panel2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Load += Form1_Load;
            panel2.ResumeLayout(false);
            panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel17.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private Panel panel2;
        private Panel panel6;
        private Panel panel4;
        private Panel panel5;
        private PictureBox pictureBox2;
        private Panel panel17;
        private Label label1;
        private PictureBox pictureBox1;
        private Label label2;
        private Label label3;
        private Label label7;
        private Label label11;
        private Label label12;
        private FontAwesome.Sharp.IconButton personel;
        private FontAwesome.Sharp.IconButton kargo;
        private FontAwesome.Sharp.IconButton satislar;
        private FontAwesome.Sharp.IconButton urunler;
        private FontAwesome.Sharp.IconButton exit;
        private FontAwesome.Sharp.IconButton minimize;
        private PictureBox pictureBox3;
        private Panel panel18;
        private Panel panel1;
        private System.Windows.Forms.Timer timer1;
    }
}