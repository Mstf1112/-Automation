﻿namespace proje_odevi
{
    partial class urunler
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(urunler));
            label1 = new Label();
            panel3 = new Panel();
            pictureBox1 = new PictureBox();
            panel17 = new Panel();
            panel16 = new Panel();
            panel15 = new Panel();
            panel14 = new Panel();
            label3 = new Label();
            panel12 = new Panel();
            panel13 = new Panel();
            label7 = new Label();
            textBox3 = new TextBox();
            panel10 = new Panel();
            panel11 = new Panel();
            label6 = new Label();
            textBox2 = new TextBox();
            panel8 = new Panel();
            panel9 = new Panel();
            label2 = new Label();
            textBox1 = new TextBox();
            dataGridView1 = new DataGridView();
            panel6 = new Panel();
            panel7 = new Panel();
            label10 = new Label();
            textBox4 = new TextBox();
            panel4 = new Panel();
            panel5 = new Panel();
            label9 = new Label();
            comboBox2 = new ComboBox();
            panel1 = new Panel();
            panel2 = new Panel();
            label8 = new Label();
            comboBox1 = new ComboBox();
            button5 = new Button();
            textBox5 = new TextBox();
            button1 = new Button();
            button4 = new Button();
            button2 = new Button();
            button3 = new Button();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel12.SuspendLayout();
            panel10.SuspendLayout();
            panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            panel6.SuspendLayout();
            panel4.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(437, 291);
            label1.Name = "label1";
            label1.Size = new Size(55, 20);
            label1.TabIndex = 1;
            label1.Text = "urunler";
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(247, 247, 247);
            panel3.Controls.Add(pictureBox1);
            panel3.Controls.Add(panel17);
            panel3.Controls.Add(panel16);
            panel3.Controls.Add(panel15);
            panel3.Controls.Add(panel14);
            panel3.Controls.Add(label3);
            panel3.Controls.Add(panel12);
            panel3.Controls.Add(panel10);
            panel3.Controls.Add(panel8);
            panel3.Controls.Add(dataGridView1);
            panel3.Controls.Add(panel6);
            panel3.Controls.Add(panel4);
            panel3.Controls.Add(panel1);
            panel3.Controls.Add(button5);
            panel3.Controls.Add(textBox5);
            panel3.Controls.Add(button1);
            panel3.Controls.Add(button4);
            panel3.Controls.Add(button2);
            panel3.Controls.Add(button3);
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(0, 0);
            panel3.Margin = new Padding(3, 4, 3, 4);
            panel3.Name = "panel3";
            panel3.Size = new Size(815, 851);
            panel3.TabIndex = 4;
            panel3.Paint += panel3_Paint;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(685, 197);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(22, 23);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 63;
            pictureBox1.TabStop = false;
            // 
            // panel17
            // 
            panel17.Anchor = AnchorStyles.None;
            panel17.BackColor = Color.LightGray;
            panel17.Location = new Point(711, 712);
            panel17.Margin = new Padding(3, 4, 3, 4);
            panel17.Name = "panel17";
            panel17.Size = new Size(1, 73);
            panel17.TabIndex = 62;
            // 
            // panel16
            // 
            panel16.Anchor = AnchorStyles.None;
            panel16.BackColor = Color.LightGray;
            panel16.Location = new Point(95, 712);
            panel16.Margin = new Padding(3, 4, 3, 4);
            panel16.Name = "panel16";
            panel16.Size = new Size(1, 73);
            panel16.TabIndex = 61;
            // 
            // panel15
            // 
            panel15.Anchor = AnchorStyles.None;
            panel15.BackColor = Color.LightGray;
            panel15.Location = new Point(95, 820);
            panel15.Margin = new Padding(3, 4, 3, 4);
            panel15.Name = "panel15";
            panel15.Size = new Size(617, 1);
            panel15.TabIndex = 32;
            // 
            // panel14
            // 
            panel14.Anchor = AnchorStyles.None;
            panel14.BackColor = Color.LightGray;
            panel14.Location = new Point(95, 677);
            panel14.Margin = new Padding(3, 4, 3, 4);
            panel14.Name = "panel14";
            panel14.Size = new Size(617, 1);
            panel14.TabIndex = 31;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.FromArgb(93, 62, 188);
            label3.Location = new Point(327, 68);
            label3.Name = "label3";
            label3.Size = new Size(129, 29);
            label3.TabIndex = 60;
            label3.Text = "ÜRÜNLER";
            // 
            // panel12
            // 
            panel12.BackColor = Color.Transparent;
            panel12.Controls.Add(panel13);
            panel12.Controls.Add(label7);
            panel12.Controls.Add(textBox3);
            panel12.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel12.ForeColor = Color.Transparent;
            panel12.Location = new Point(431, 476);
            panel12.Margin = new Padding(3, 4, 3, 4);
            panel12.Name = "panel12";
            panel12.Size = new Size(257, 112);
            panel12.TabIndex = 59;
            // 
            // panel13
            // 
            panel13.Anchor = AnchorStyles.None;
            panel13.BackColor = Color.LightGray;
            panel13.Location = new Point(9, 77);
            panel13.Margin = new Padding(3, 4, 3, 4);
            panel13.Name = "panel13";
            panel13.Size = new Size(237, 1);
            panel13.TabIndex = 30;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label7.ForeColor = Color.FromArgb(93, 62, 188);
            label7.Location = new Point(0, 0);
            label7.Name = "label7";
            label7.Size = new Size(33, 15);
            label7.TabIndex = 56;
            label7.Text = "Stok";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(9, 44);
            textBox3.Margin = new Padding(3, 4, 3, 4);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(236, 21);
            textBox3.TabIndex = 11;
            // 
            // panel10
            // 
            panel10.BackColor = Color.Transparent;
            panel10.Controls.Add(panel11);
            panel10.Controls.Add(label6);
            panel10.Controls.Add(textBox2);
            panel10.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel10.ForeColor = Color.Transparent;
            panel10.Location = new Point(431, 368);
            panel10.Margin = new Padding(3, 4, 3, 4);
            panel10.Name = "panel10";
            panel10.Size = new Size(257, 112);
            panel10.TabIndex = 58;
            // 
            // panel11
            // 
            panel11.Anchor = AnchorStyles.None;
            panel11.BackColor = Color.LightGray;
            panel11.Location = new Point(9, 79);
            panel11.Margin = new Padding(3, 4, 3, 4);
            panel11.Name = "panel11";
            panel11.Size = new Size(237, 1);
            panel11.TabIndex = 30;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.FromArgb(93, 62, 188);
            label6.Location = new Point(0, 0);
            label6.Name = "label6";
            label6.Size = new Size(66, 15);
            label6.TabIndex = 56;
            label6.Text = "Ürün Fiyatı";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(9, 41);
            textBox2.Margin = new Padding(3, 4, 3, 4);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(236, 21);
            textBox2.TabIndex = 10;
            // 
            // panel8
            // 
            panel8.BackColor = Color.Transparent;
            panel8.Controls.Add(panel9);
            panel8.Controls.Add(label2);
            panel8.Controls.Add(textBox1);
            panel8.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel8.ForeColor = Color.Transparent;
            panel8.Location = new Point(431, 256);
            panel8.Margin = new Padding(3, 4, 3, 4);
            panel8.Name = "panel8";
            panel8.Size = new Size(257, 112);
            panel8.TabIndex = 57;
            // 
            // panel9
            // 
            panel9.Anchor = AnchorStyles.None;
            panel9.BackColor = Color.LightGray;
            panel9.Location = new Point(9, 79);
            panel9.Margin = new Padding(3, 4, 3, 4);
            panel9.Name = "panel9";
            panel9.Size = new Size(237, 1);
            panel9.TabIndex = 30;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.FromArgb(93, 62, 188);
            label2.Location = new Point(0, 0);
            label2.Name = "label2";
            label2.Size = new Size(55, 15);
            label2.TabIndex = 56;
            label2.Text = "Ürün Adı";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(9, 43);
            textBox1.Margin = new Padding(3, 4, 3, 4);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(236, 21);
            textBox1.TabIndex = 9;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.FromArgb(93, 62, 188);
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(114, 687);
            dataGridView1.Margin = new Padding(3, 4, 3, 4);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(582, 125);
            dataGridView1.TabIndex = 13;
            dataGridView1.CellMouseClick += dataGridView1_CellMouseClick;
            // 
            // panel6
            // 
            panel6.BackColor = Color.Transparent;
            panel6.Controls.Add(panel7);
            panel6.Controls.Add(label10);
            panel6.Controls.Add(textBox4);
            panel6.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel6.ForeColor = Color.Transparent;
            panel6.Location = new Point(114, 476);
            panel6.Margin = new Padding(3, 4, 3, 4);
            panel6.Name = "panel6";
            panel6.Size = new Size(257, 112);
            panel6.TabIndex = 58;
            // 
            // panel7
            // 
            panel7.Anchor = AnchorStyles.None;
            panel7.BackColor = Color.LightGray;
            panel7.Location = new Point(9, 80);
            panel7.Margin = new Padding(3, 4, 3, 4);
            panel7.Name = "panel7";
            panel7.Size = new Size(237, 1);
            panel7.TabIndex = 30;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label10.ForeColor = Color.FromArgb(93, 62, 188);
            label10.Location = new Point(0, 0);
            label10.Name = "label10";
            label10.Size = new Size(60, 15);
            label10.TabIndex = 56;
            label10.Text = "Açıklama";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(9, 47);
            textBox4.Margin = new Padding(3, 4, 3, 4);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(236, 21);
            textBox4.TabIndex = 12;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Transparent;
            panel4.Controls.Add(panel5);
            panel4.Controls.Add(label9);
            panel4.Controls.Add(comboBox2);
            panel4.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel4.ForeColor = Color.Transparent;
            panel4.Location = new Point(114, 368);
            panel4.Margin = new Padding(3, 4, 3, 4);
            panel4.Name = "panel4";
            panel4.Size = new Size(257, 112);
            panel4.TabIndex = 57;
            // 
            // panel5
            // 
            panel5.Anchor = AnchorStyles.None;
            panel5.BackColor = Color.LightGray;
            panel5.Location = new Point(9, 79);
            panel5.Margin = new Padding(3, 4, 3, 4);
            panel5.Name = "panel5";
            panel5.Size = new Size(237, 1);
            panel5.TabIndex = 30;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label9.ForeColor = Color.FromArgb(93, 62, 188);
            label9.Location = new Point(0, 0);
            label9.Name = "label9";
            label9.Size = new Size(43, 15);
            label9.TabIndex = 56;
            label9.Text = "Marka";
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20" });
            comboBox2.Location = new Point(9, 41);
            comboBox2.Margin = new Padding(3, 4, 3, 4);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(236, 23);
            comboBox2.TabIndex = 31;
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Transparent;
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(comboBox1);
            panel1.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel1.ForeColor = Color.Transparent;
            panel1.Location = new Point(114, 256);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(257, 112);
            panel1.TabIndex = 50;
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.None;
            panel2.BackColor = Color.LightGray;
            panel2.Location = new Point(9, 79);
            panel2.Margin = new Padding(3, 4, 3, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(237, 1);
            panel2.TabIndex = 30;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = Color.FromArgb(93, 62, 188);
            label8.Location = new Point(0, 0);
            label8.Name = "label8";
            label8.Size = new Size(55, 15);
            label8.TabIndex = 56;
            label8.Text = "Kategori";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "1", "2", "3", "4", "5", "6", "7", "8" });
            comboBox1.Location = new Point(9, 40);
            comboBox1.Margin = new Padding(3, 4, 3, 4);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(236, 23);
            comboBox1.TabIndex = 1;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(93, 62, 188);
            button5.FlatAppearance.BorderColor = Color.FromArgb(93, 62, 188);
            button5.FlatAppearance.BorderSize = 2;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button5.ForeColor = Color.White;
            button5.Location = new Point(415, 609);
            button5.Margin = new Padding(3, 4, 3, 4);
            button5.Name = "button5";
            button5.Size = new Size(128, 47);
            button5.TabIndex = 33;
            button5.Text = "Ürünü Güncelle";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            button5.MouseEnter += button5_MouseEnter;
            button5.MouseLeave += button5_MouseLeave;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(95, 195);
            textBox5.Margin = new Padding(3, 4, 3, 4);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(617, 27);
            textBox5.TabIndex = 30;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(93, 62, 188);
            button1.FlatAppearance.BorderColor = Color.FromArgb(93, 62, 188);
            button1.FlatAppearance.BorderSize = 2;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button1.ForeColor = Color.White;
            button1.Location = new Point(317, 131);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(171, 40);
            button1.TabIndex = 29;
            button1.Text = "Ürün Ara";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            button1.MouseEnter += button1_MouseEnter;
            button1.MouseLeave += button1_MouseLeave;
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(93, 62, 188);
            button4.FlatAppearance.BorderColor = Color.FromArgb(93, 62, 188);
            button4.FlatAppearance.BorderSize = 2;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button4.ForeColor = Color.White;
            button4.Location = new Point(270, 609);
            button4.Margin = new Padding(3, 4, 3, 4);
            button4.Name = "button4";
            button4.Size = new Size(128, 47);
            button4.TabIndex = 28;
            button4.Text = "Ürün Kaldır";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            button4.MouseEnter += button4_MouseEnter;
            button4.MouseLeave += button4_MouseLeave;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(93, 62, 188);
            button2.FlatAppearance.BorderColor = Color.FromArgb(93, 62, 188);
            button2.FlatAppearance.BorderSize = 2;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button2.ForeColor = Color.White;
            button2.Location = new Point(560, 609);
            button2.Margin = new Padding(3, 4, 3, 4);
            button2.Name = "button2";
            button2.Size = new Size(128, 47);
            button2.TabIndex = 27;
            button2.Text = "Ürünleri Listele";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            button2.MouseEnter += button2_MouseEnter;
            button2.MouseLeave += button2_MouseLeave;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(93, 62, 188);
            button3.FlatAppearance.BorderColor = Color.FromArgb(93, 62, 188);
            button3.FlatAppearance.BorderSize = 2;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button3.ForeColor = Color.White;
            button3.Location = new Point(123, 609);
            button3.Margin = new Padding(3, 4, 3, 4);
            button3.Name = "button3";
            button3.Size = new Size(128, 47);
            button3.TabIndex = 26;
            button3.Text = "Ürün Ekle";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            button3.MouseEnter += button3_MouseEnter;
            button3.MouseLeave += button3_MouseLeave;
            // 
            // urunler
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(815, 851);
            Controls.Add(panel3);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "urunler";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "urunler";
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel12.ResumeLayout(false);
            panel12.PerformLayout();
            panel10.ResumeLayout(false);
            panel10.PerformLayout();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private ComboBox comboBox1;
        private DataGridView dataGridView1;
        private TextBox textBox4;
        private TextBox textBox3;
        private TextBox textBox2;
        private TextBox textBox1;
        private Button button4;
        private Button button2;
        private Button button3;
        private TextBox textBox5;
        private ComboBox comboBox2;
        private Button button5;
        private Label label8;
        private Panel panel6;
        private Panel panel7;
        private Label label10;
        private Panel panel4;
        private Panel panel5;
        private Label label9;
        private Panel panel12;
        private Panel panel13;
        private Label label7;
        private Panel panel10;
        private Panel panel11;
        private Label label6;
        private Panel panel8;
        private Panel panel9;
        private Label label2;
        private Label label3;
        private Panel panel17;
        private Panel panel16;
        private Panel panel15;
        private Panel panel14;
        private PictureBox pictureBox1;
        private Button button1;
    }
}