﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace proje_odevi
{
    public partial class satislar : Form
    {
        public satislar()
        {
            InitializeComponent();
        }



        // Veritabanı bağlantısı oluşturma

        static string constring = "Data Source=FURKAN\\SQLEXPRESS;Initial Catalog=Nalbur_DB;Integrated Security=True;";
        SqlConnection baglanti = new SqlConnection(constring);



        // Listele butonu için oluşturduğumuz veri tabanı kayıtlarını data grid view üzerinde gösterdiğimiz fonksiyonun oluşum kısmı

        public void kayitlari_goruntule()
        {


            string kayitlari_goruntule = "Select * From Siparisler";

            SqlCommand goruntuleme_komutu = new SqlCommand(kayitlari_goruntule, baglanti);

            SqlDataAdapter Adapter = new SqlDataAdapter(goruntuleme_komutu);

            DataTable DataTable = new DataTable();
            Adapter.Fill(DataTable);
            dataGridView1.DataSource = DataTable;




        }

        // Sil butonu için oluşturduğumuz veri tabanı kayıtlarını silen fonksiyonun oluşum kısmı

        public void kayitlari_sil(int SiparisID)
        {



            string kayitlari_sil = "Delete From Siparisler Where SiparisID=@SiparisID";

            SqlCommand silme_komutu = new SqlCommand(kayitlari_sil, baglanti);


            baglanti.Open();

            silme_komutu.Parameters.AddWithValue("@SiparisID", SiparisID);

            silme_komutu.ExecuteNonQuery();



            baglanti.Close();
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }






        private void button3_Click(object sender, EventArgs e)
        {
            string kayitlari_ara = "Select * From Siparisler Where Detay=@Detay";

            SqlCommand arama_komutu = new SqlCommand(kayitlari_ara, baglanti);

            arama_komutu.Parameters.AddWithValue("@Detay", textBox6.Text);


            SqlDataAdapter Adapter = new SqlDataAdapter(arama_komutu);

            DataTable DataTable = new DataTable();
            Adapter.Fill(DataTable);
            dataGridView1.DataSource = DataTable;

            baglanti.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            kayitlari_goruntule();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow drow in dataGridView1.SelectedRows)
            {
                int UrunlerID = Convert.ToInt32(drow.Cells[0].Value);
                kayitlari_sil(UrunlerID);
                kayitlari_goruntule();
            }
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        // Birim fiyat ve adet kısmının zorunlu olarak girilmesi gereken yerler olarak belirlediğimiz kısım
        // bu kısımda iki alanı toplayarak toplam tutar kısmına yazdırdığımız fonksiyonda barınmaktadır

        private void toplam_tutar (object sender, EventArgs e)
        {
            if ( double.TryParse (textBox1.Text, out double deger1) && double.TryParse (textBox5.Text, out double deger2) )
            {

                double islem = deger1 * deger2;


                textBox3.Text = islem.ToString();
                label4.Visible = false;
            }
            else
            {
                label4.Visible = true;
            }
        }

        // Toplam tutar fonksiyonları çalıştırdığımız kısım
        // Combo boxımıza tekrardan veri tabanından ürünleri çektiğimiz kısımda bulunmaktadır

        private void satislar_Load(object sender, EventArgs e)
        {

            textBox1.TextChanged += toplam_tutar;
            textBox5.TextChanged += toplam_tutar;


            SqlCommand combo_boxa_veri_aktarma = new SqlCommand("Select * From Urunler", baglanti);

            SqlCommand combo_boxa2_veri_aktarma = new SqlCommand("Select * From Musteri", baglanti);

            SqlDataReader cbva;

            SqlDataReader cbva2;



            baglanti.Open();



            cbva = combo_boxa_veri_aktarma.ExecuteReader();




            while (cbva.Read())
            {
                comboBox3.Items.Add(cbva["UrunAdi"]);
            }

            baglanti.Close();



            baglanti.Open();

            cbva2 = combo_boxa2_veri_aktarma.ExecuteReader();

            while (cbva2.Read())
            {
                // comboBox4.Items.Add(cbva2["MusteriID"]);
            }

            baglanti.Close();
        }




        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        // Ekle butonu için veri tabanına ekleme yaptırdığımız fonksiyonun oluşum kısmı

        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                if (baglanti.State == ConnectionState.Closed)
                {
                    baglanti.Open();

                    string kaydetme = "insert into Siparisler (BirimFiyat,Detay,SiparisTarihi,ToplamTutar,SiparisDurumu,OdemeTuru) values(@BirimFiyat,@Detay,@SiparisTarihi,@ToplamTutar,@SiparisDurumu,@OdemeTuru)";


                    SqlCommand kaydetme_komutu = new SqlCommand(kaydetme, baglanti);

                    kaydetme_komutu.Parameters.AddWithValue("@BirimFiyat", textBox1.Text);
                    kaydetme_komutu.Parameters.AddWithValue("@Detay", textBox2.Text);
                    kaydetme_komutu.Parameters.AddWithValue("@SiparisTarihi", maskedTextBox1.Text);
                    kaydetme_komutu.Parameters.AddWithValue("@ToplamTutar", textBox3.Text);
                    kaydetme_komutu.Parameters.AddWithValue("@SiparisDurumu", comboBox1.SelectedItem);
                    kaydetme_komutu.Parameters.AddWithValue("@OdemeTuru", comboBox2.SelectedItem);


                    




                    kaydetme_komutu.ExecuteNonQuery();

                    

                    MessageBox.Show("Sipariş Kaydınız Başarıyla Eklendi.", "Sipariş Kayıt İşlemi");
                }

            }

            catch (Exception kaydedilmedi)
            {

                MessageBox.Show("Kayıt Eklenemedi.", kaydedilmedi.Message);

            }
        }

        

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
               
        }
    }
}
