﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace proje_odevi
{
    public partial class sifremi_unuttum2 : Form
    {
        public sifremi_unuttum2()
        {
            InitializeComponent();
        }


        // Veritabanı bağlantısı oluşturma  

        static string constring = "Data Source=FURKAN\\SQLEXPRESS;Initial Catalog=giris_ekrani;Integrated Security=True;";
        SqlConnection baglanti = new SqlConnection(constring);



        private void exit_Click(object sender, EventArgs e)
        {
            giris_ekrani Kayit_Ekrani = new giris_ekrani();
            Kayit_Ekrani.Show();
            this.Hide();
        }

        private void minimize_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_MouseClick(object sender, MouseEventArgs e)
        {
            textBox1.SelectAll();
        }

        private void textBox2_MouseClick(object sender, MouseEventArgs e)
        {
            textBox2.SelectAll();
        }

        // Doğrulama işleminin sonrasında veri tabanındaki eski bilgilerin güncellendiği fonksiyonun oluşum kısmı 

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == textBox2.Text)
                {

                    if (baglanti.State == ConnectionState.Closed)
                    {
                        baglanti.Open();

                        string güncelleme = "UPDATE Kullanici SET Sifre=@Sifre";

                        SqlCommand güncelleme_komutu = new SqlCommand(güncelleme, baglanti);

                        güncelleme_komutu.Parameters.AddWithValue("@Sifre", textBox1.Text);



                        güncelleme_komutu.ExecuteNonQuery();

                        MessageBox.Show("Şifreniz Başarıyla Yenilendi.", "Güncelleme İşlemi");
                        
                    }


                    else
                    {
                        MessageBox.Show("Şifre Yenilenemedi.");
                    }
                }
                
                else 
                {

                    panel4.Visible = true;
                
                }

             




            }
            catch (Exception hata)
            {
                MessageBox.Show("Güncelleme Hatası: " + hata.Message);
            }
        }
    }
}
