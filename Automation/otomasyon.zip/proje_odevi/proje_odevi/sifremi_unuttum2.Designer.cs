﻿namespace proje_odevi
{
    partial class sifremi_unuttum2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(sifremi_unuttum2));
            exit = new FontAwesome.Sharp.IconButton();
            minimize = new FontAwesome.Sharp.IconButton();
            panel4 = new Panel();
            label4 = new Label();
            panel3 = new Panel();
            panel5 = new Panel();
            panel6 = new Panel();
            textBox2 = new TextBox();
            label5 = new Label();
            panel1 = new Panel();
            panel2 = new Panel();
            textBox1 = new TextBox();
            label2 = new Label();
            label1 = new Label();
            button1 = new Button();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // exit
            // 
            exit.BackColor = Color.Transparent;
            exit.BackgroundImage = (Image)resources.GetObject("exit.BackgroundImage");
            exit.BackgroundImageLayout = ImageLayout.Zoom;
            exit.FlatAppearance.BorderSize = 0;
            exit.FlatStyle = FlatStyle.Flat;
            exit.ForeColor = SystemColors.ControlText;
            exit.IconChar = FontAwesome.Sharp.IconChar.None;
            exit.IconColor = Color.Black;
            exit.IconFont = FontAwesome.Sharp.IconFont.Auto;
            exit.Location = new Point(1296, 32);
            exit.Margin = new Padding(3, 4, 3, 4);
            exit.Name = "exit";
            exit.Size = new Size(19, 23);
            exit.TabIndex = 26;
            exit.UseVisualStyleBackColor = false;
            exit.Click += exit_Click;
            // 
            // minimize
            // 
            minimize.BackColor = Color.Transparent;
            minimize.BackgroundImage = (Image)resources.GetObject("minimize.BackgroundImage");
            minimize.BackgroundImageLayout = ImageLayout.Zoom;
            minimize.FlatAppearance.BorderSize = 0;
            minimize.FlatStyle = FlatStyle.Flat;
            minimize.IconChar = FontAwesome.Sharp.IconChar.None;
            minimize.IconColor = Color.Black;
            minimize.IconFont = FontAwesome.Sharp.IconFont.Auto;
            minimize.Location = new Point(1270, 32);
            minimize.Margin = new Padding(3, 4, 3, 4);
            minimize.Name = "minimize";
            minimize.Size = new Size(19, 23);
            minimize.TabIndex = 25;
            minimize.UseVisualStyleBackColor = false;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Transparent;
            panel4.Controls.Add(label4);
            panel4.ForeColor = Color.Transparent;
            panel4.Location = new Point(465, 501);
            panel4.Margin = new Padding(3, 4, 3, 4);
            panel4.Name = "panel4";
            panel4.Size = new Size(345, 37);
            panel4.TabIndex = 43;
            panel4.Visible = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Dock = DockStyle.Left;
            label4.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.Red;
            label4.Location = new Point(0, 0);
            label4.Name = "label4";
            label4.Size = new Size(131, 15);
            label4.TabIndex = 0;
            label4.Text = "Şifreleriniz Uyuşmuyor.";
            // 
            // panel3
            // 
            panel3.BackColor = Color.Transparent;
            panel3.ForeColor = Color.Transparent;
            panel3.Location = new Point(465, 364);
            panel3.Margin = new Padding(3, 4, 3, 4);
            panel3.Name = "panel3";
            panel3.Size = new Size(345, 37);
            panel3.TabIndex = 40;
            panel3.Visible = false;
            // 
            // panel5
            // 
            panel5.BackColor = Color.Transparent;
            panel5.Controls.Add(panel6);
            panel5.Controls.Add(textBox2);
            panel5.ForeColor = Color.Transparent;
            panel5.Location = new Point(465, 403);
            panel5.Margin = new Padding(3, 4, 3, 4);
            panel5.Name = "panel5";
            panel5.Size = new Size(345, 112);
            panel5.TabIndex = 42;
            // 
            // panel6
            // 
            panel6.Anchor = AnchorStyles.None;
            panel6.BackColor = Color.LightGray;
            panel6.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel6.Location = new Point(6, 67);
            panel6.Margin = new Padding(3, 4, 3, 4);
            panel6.Name = "panel6";
            panel6.Size = new Size(334, 1);
            panel6.TabIndex = 30;
            // 
            // textBox2
            // 
            textBox2.Anchor = AnchorStyles.None;
            textBox2.BackColor = SystemColors.Control;
            textBox2.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            textBox2.ForeColor = Color.Gray;
            textBox2.Location = new Point(6, 28);
            textBox2.Margin = new Padding(3, 4, 3, 4);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(334, 21);
            textBox2.TabIndex = 26;
            textBox2.Text = "Şifrenizi Tekrar Girin.";
            textBox2.MouseClick += textBox2_MouseClick;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = Color.FromArgb(93, 62, 188);
            label5.Location = new Point(280, 439);
            label5.Name = "label5";
            label5.Size = new Size(122, 15);
            label5.TabIndex = 41;
            label5.Text = "Şifrenizi Tekrar Girin";
            // 
            // panel1
            // 
            panel1.BackColor = Color.Transparent;
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(textBox1);
            panel1.ForeColor = Color.Transparent;
            panel1.Location = new Point(465, 260);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(345, 112);
            panel1.TabIndex = 39;
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.None;
            panel2.BackColor = Color.LightGray;
            panel2.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel2.Location = new Point(8, 81);
            panel2.Margin = new Padding(3, 4, 3, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(328, 1);
            panel2.TabIndex = 30;
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.None;
            textBox1.BackColor = SystemColors.Control;
            textBox1.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            textBox1.ForeColor = Color.Gray;
            textBox1.Location = new Point(8, 43);
            textBox1.Margin = new Padding(3, 4, 3, 4);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(329, 21);
            textBox1.TabIndex = 26;
            textBox1.Text = "Yeni Şifrenizi Girin.";
            textBox1.MouseClick += textBox1_MouseClick;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.FromArgb(93, 62, 188);
            label2.Location = new Point(351, 311);
            label2.Name = "label2";
            label2.Size = new Size(60, 15);
            label2.TabIndex = 38;
            label2.Text = "Yeni Şifre";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 15F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.FromArgb(93, 62, 188);
            label1.Location = new Point(541, 129);
            label1.Name = "label1";
            label1.Size = new Size(177, 24);
            label1.TabIndex = 37;
            label1.Text = "ŞİFRE SIFIRLAMA";
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(93, 62, 188);
            button1.FlatAppearance.BorderColor = Color.FromArgb(93, 62, 188);
            button1.FlatAppearance.BorderSize = 2;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Arial", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            button1.ForeColor = Color.FromArgb(248, 247, 247);
            button1.Location = new Point(465, 579);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(345, 55);
            button1.TabIndex = 36;
            button1.Text = "Giriş";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // sifremi_unuttum2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(247, 247, 247);
            ClientSize = new Size(1342, 799);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel5);
            Controls.Add(label5);
            Controls.Add(panel1);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(exit);
            Controls.Add(minimize);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "sifremi_unuttum2";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "sifremi_unuttum2";
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private FontAwesome.Sharp.IconButton exit;
        private FontAwesome.Sharp.IconButton minimize;
        private Panel panel4;
        private Label label4;
        private Panel panel3;
        private Panel panel5;
        private Panel panel6;
        private TextBox textBox2;
        private Label label5;
        private Panel panel1;
        private Panel panel2;
        private TextBox textBox1;
        private Label label2;
        private Label label1;
        private Button button1;
    }
}