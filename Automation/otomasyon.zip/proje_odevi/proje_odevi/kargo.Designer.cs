﻿namespace proje_odevi
{
    partial class kargo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(kargo));
            label1 = new Label();
            panel2 = new Panel();
            panel19 = new Panel();
            textBox1 = new TextBox();
            panel20 = new Panel();
            label9 = new Label();
            button2 = new Button();
            button3 = new Button();
            pictureBox1 = new PictureBox();
            textBox5 = new TextBox();
            button1 = new Button();
            panel7 = new Panel();
            comboBox2 = new ComboBox();
            panel18 = new Panel();
            label5 = new Label();
            panel12 = new Panel();
            panel13 = new Panel();
            label7 = new Label();
            textBox3 = new TextBox();
            panel10 = new Panel();
            panel11 = new Panel();
            label6 = new Label();
            textBox2 = new TextBox();
            panel8 = new Panel();
            comboBox1 = new ComboBox();
            panel9 = new Panel();
            label4 = new Label();
            panel5 = new Panel();
            panel6 = new Panel();
            label2 = new Label();
            comboBox4 = new ComboBox();
            panel3 = new Panel();
            panel4 = new Panel();
            label8 = new Label();
            comboBox3 = new ComboBox();
            panel17 = new Panel();
            panel1 = new Panel();
            panel15 = new Panel();
            panel14 = new Panel();
            label3 = new Label();
            dataGridView1 = new DataGridView();
            panel16 = new Panel();
            panel2.SuspendLayout();
            panel19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel7.SuspendLayout();
            panel12.SuspendLayout();
            panel10.SuspendLayout();
            panel8.SuspendLayout();
            panel5.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(547, 285);
            label1.Name = "label1";
            label1.Size = new Size(47, 20);
            label1.TabIndex = 0;
            label1.Text = "kargo";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(247, 247, 247);
            panel2.Controls.Add(panel19);
            panel2.Controls.Add(button2);
            panel2.Controls.Add(button3);
            panel2.Controls.Add(pictureBox1);
            panel2.Controls.Add(textBox5);
            panel2.Controls.Add(button1);
            panel2.Controls.Add(panel7);
            panel2.Controls.Add(panel12);
            panel2.Controls.Add(panel10);
            panel2.Controls.Add(panel8);
            panel2.Controls.Add(panel5);
            panel2.Controls.Add(panel3);
            panel2.Controls.Add(panel17);
            panel2.Controls.Add(panel1);
            panel2.Controls.Add(panel15);
            panel2.Controls.Add(panel14);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(dataGridView1);
            panel2.Controls.Add(panel16);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Margin = new Padding(3, 4, 3, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(815, 851);
            panel2.TabIndex = 7;
            // 
            // panel19
            // 
            panel19.BackColor = Color.Transparent;
            panel19.Controls.Add(textBox1);
            panel19.Controls.Add(panel20);
            panel19.Controls.Add(label9);
            panel19.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel19.ForeColor = Color.Transparent;
            panel19.Location = new Point(547, 249);
            panel19.Margin = new Padding(3, 4, 3, 4);
            panel19.Name = "panel19";
            panel19.Size = new Size(257, 112);
            panel19.TabIndex = 84;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(9, 40);
            textBox1.Margin = new Padding(3, 4, 3, 4);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(236, 21);
            textBox1.TabIndex = 86;
            // 
            // panel20
            // 
            panel20.Anchor = AnchorStyles.None;
            panel20.BackColor = Color.LightGray;
            panel20.Location = new Point(9, 79);
            panel20.Margin = new Padding(3, 4, 3, 4);
            panel20.Name = "panel20";
            panel20.Size = new Size(237, 1);
            panel20.TabIndex = 30;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label9.ForeColor = Color.FromArgb(93, 62, 188);
            label9.Location = new Point(0, 0);
            label9.Name = "label9";
            label9.Size = new Size(55, 15);
            label9.TabIndex = 56;
            label9.Text = "Kargo İD";
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(93, 62, 188);
            button2.FlatAppearance.BorderColor = Color.FromArgb(93, 62, 188);
            button2.FlatAppearance.BorderSize = 2;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button2.ForeColor = Color.White;
            button2.Location = new Point(411, 609);
            button2.Margin = new Padding(3, 4, 3, 4);
            button2.Name = "button2";
            button2.Size = new Size(128, 47);
            button2.TabIndex = 84;
            button2.Text = "Kargoları Listele";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(93, 62, 188);
            button3.FlatAppearance.BorderColor = Color.FromArgb(93, 62, 188);
            button3.FlatAppearance.BorderSize = 2;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button3.ForeColor = Color.White;
            button3.Location = new Point(265, 609);
            button3.Margin = new Padding(3, 4, 3, 4);
            button3.Name = "button3";
            button3.Size = new Size(128, 47);
            button3.TabIndex = 83;
            button3.Text = "Kargo Oluştur";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(685, 197);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(22, 23);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 82;
            pictureBox1.TabStop = false;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(95, 195);
            textBox5.Margin = new Padding(3, 4, 3, 4);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(617, 27);
            textBox5.TabIndex = 81;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(93, 62, 188);
            button1.FlatAppearance.BorderColor = Color.FromArgb(93, 62, 188);
            button1.FlatAppearance.BorderSize = 2;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button1.ForeColor = Color.White;
            button1.Location = new Point(314, 111);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(171, 40);
            button1.TabIndex = 80;
            button1.Text = "Kargo Ara";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // panel7
            // 
            panel7.BackColor = Color.Transparent;
            panel7.Controls.Add(comboBox2);
            panel7.Controls.Add(panel18);
            panel7.Controls.Add(label5);
            panel7.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel7.ForeColor = Color.Transparent;
            panel7.Location = new Point(97, 487);
            panel7.Margin = new Padding(3, 4, 3, 4);
            panel7.Name = "panel7";
            panel7.Size = new Size(257, 112);
            panel7.TabIndex = 79;
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "Aynı Gün Teslimat", "1-3 İş Günü İçinde Teslimat", "3-5 İş Günü İçinde Teslimat", "7+ İş Günü İçinde Teslimat" });
            comboBox2.Location = new Point(9, 41);
            comboBox2.Margin = new Padding(3, 4, 3, 4);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(236, 23);
            comboBox2.TabIndex = 83;
            // 
            // panel18
            // 
            panel18.Anchor = AnchorStyles.None;
            panel18.BackColor = Color.LightGray;
            panel18.Location = new Point(9, 80);
            panel18.Margin = new Padding(3, 4, 3, 4);
            panel18.Name = "panel18";
            panel18.Size = new Size(237, 1);
            panel18.TabIndex = 30;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = Color.FromArgb(93, 62, 188);
            label5.Location = new Point(0, 0);
            label5.Name = "label5";
            label5.Size = new Size(102, 15);
            label5.TabIndex = 56;
            label5.Text = "Tahmini Teslimat";
            // 
            // panel12
            // 
            panel12.BackColor = Color.Transparent;
            panel12.Controls.Add(panel13);
            panel12.Controls.Add(label7);
            panel12.Controls.Add(textBox3);
            panel12.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel12.ForeColor = Color.Transparent;
            panel12.Location = new Point(439, 487);
            panel12.Margin = new Padding(3, 4, 3, 4);
            panel12.Name = "panel12";
            panel12.Size = new Size(257, 112);
            panel12.TabIndex = 78;
            // 
            // panel13
            // 
            panel13.Anchor = AnchorStyles.None;
            panel13.BackColor = Color.LightGray;
            panel13.Location = new Point(9, 80);
            panel13.Margin = new Padding(3, 4, 3, 4);
            panel13.Name = "panel13";
            panel13.Size = new Size(237, 1);
            panel13.TabIndex = 30;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label7.ForeColor = Color.FromArgb(93, 62, 188);
            label7.Location = new Point(0, 0);
            label7.Name = "label7";
            label7.Size = new Size(26, 15);
            label7.TabIndex = 56;
            label7.Text = "Not";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(9, 44);
            textBox3.Margin = new Padding(3, 4, 3, 4);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(236, 21);
            textBox3.TabIndex = 11;
            // 
            // panel10
            // 
            panel10.BackColor = Color.Transparent;
            panel10.Controls.Add(panel11);
            panel10.Controls.Add(label6);
            panel10.Controls.Add(textBox2);
            panel10.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel10.ForeColor = Color.Transparent;
            panel10.Location = new Point(439, 379);
            panel10.Margin = new Padding(3, 4, 3, 4);
            panel10.Name = "panel10";
            panel10.Size = new Size(257, 112);
            panel10.TabIndex = 77;
            // 
            // panel11
            // 
            panel11.Anchor = AnchorStyles.None;
            panel11.BackColor = Color.LightGray;
            panel11.Location = new Point(9, 75);
            panel11.Margin = new Padding(3, 4, 3, 4);
            panel11.Name = "panel11";
            panel11.Size = new Size(237, 1);
            panel11.TabIndex = 30;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.FromArgb(93, 62, 188);
            label6.Location = new Point(0, 0);
            label6.Name = "label6";
            label6.Size = new Size(48, 15);
            label6.TabIndex = 56;
            label6.Text = "İletişim";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(9, 41);
            textBox2.Margin = new Padding(3, 4, 3, 4);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(236, 21);
            textBox2.TabIndex = 10;
            // 
            // panel8
            // 
            panel8.BackColor = Color.Transparent;
            panel8.Controls.Add(comboBox1);
            panel8.Controls.Add(panel9);
            panel8.Controls.Add(label4);
            panel8.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel8.ForeColor = Color.Transparent;
            panel8.Location = new Point(278, 249);
            panel8.Margin = new Padding(3, 4, 3, 4);
            panel8.Name = "panel8";
            panel8.Size = new Size(257, 112);
            panel8.TabIndex = 76;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(9, 40);
            comboBox1.Margin = new Padding(3, 4, 3, 4);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(236, 23);
            comboBox1.TabIndex = 83;
            // 
            // panel9
            // 
            panel9.Anchor = AnchorStyles.None;
            panel9.BackColor = Color.LightGray;
            panel9.Location = new Point(9, 79);
            panel9.Margin = new Padding(3, 4, 3, 4);
            panel9.Name = "panel9";
            panel9.Size = new Size(237, 1);
            panel9.TabIndex = 30;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.FromArgb(93, 62, 188);
            label4.Location = new Point(0, 0);
            label4.Name = "label4";
            label4.Size = new Size(55, 15);
            label4.TabIndex = 56;
            label4.Text = "Kargocu";
            // 
            // panel5
            // 
            panel5.BackColor = Color.Transparent;
            panel5.Controls.Add(panel6);
            panel5.Controls.Add(label2);
            panel5.Controls.Add(comboBox4);
            panel5.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel5.ForeColor = Color.Transparent;
            panel5.Location = new Point(97, 375);
            panel5.Margin = new Padding(3, 4, 3, 4);
            panel5.Name = "panel5";
            panel5.Size = new Size(257, 112);
            panel5.TabIndex = 75;
            // 
            // panel6
            // 
            panel6.Anchor = AnchorStyles.None;
            panel6.BackColor = Color.LightGray;
            panel6.Location = new Point(-270, -291);
            panel6.Margin = new Padding(3, 4, 3, 4);
            panel6.Name = "panel6";
            panel6.Size = new Size(237, 1);
            panel6.TabIndex = 30;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.FromArgb(93, 62, 188);
            label2.Location = new Point(0, 0);
            label2.Name = "label2";
            label2.Size = new Size(86, 15);
            label2.TabIndex = 56;
            label2.Text = "Kargo Firması";
            // 
            // comboBox4
            // 
            comboBox4.FormattingEnabled = true;
            comboBox4.Items.AddRange(new object[] { "Aras Kargo", "Sürat Kargo", "MNG Kargo", "PTT Kargo ", "Yurtiçi Kargo" });
            comboBox4.Location = new Point(9, 40);
            comboBox4.Margin = new Padding(3, 4, 3, 4);
            comboBox4.Name = "comboBox4";
            comboBox4.Size = new Size(236, 23);
            comboBox4.TabIndex = 1;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Transparent;
            panel3.Controls.Add(panel4);
            panel3.Controls.Add(label8);
            panel3.Controls.Add(comboBox3);
            panel3.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel3.ForeColor = Color.Transparent;
            panel3.Location = new Point(9, 253);
            panel3.Margin = new Padding(3, 4, 3, 4);
            panel3.Name = "panel3";
            panel3.Size = new Size(257, 112);
            panel3.TabIndex = 74;
            // 
            // panel4
            // 
            panel4.Anchor = AnchorStyles.None;
            panel4.BackColor = Color.LightGray;
            panel4.Location = new Point(9, 79);
            panel4.Margin = new Padding(3, 4, 3, 4);
            panel4.Name = "panel4";
            panel4.Size = new Size(237, 1);
            panel4.TabIndex = 30;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = Color.FromArgb(93, 62, 188);
            label8.Location = new Point(0, 0);
            label8.Name = "label8";
            label8.Size = new Size(95, 15);
            label8.TabIndex = 56;
            label8.Text = "Sipariş Durumu";
            // 
            // comboBox3
            // 
            comboBox3.FormattingEnabled = true;
            comboBox3.Items.AddRange(new object[] { "Transfer Merkezinde", "Teslimat Şubesinde", "Dağıtımda", "Teslim Edildi" });
            comboBox3.Location = new Point(9, 40);
            comboBox3.Margin = new Padding(3, 4, 3, 4);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(236, 23);
            comboBox3.TabIndex = 1;
            // 
            // panel17
            // 
            panel17.Anchor = AnchorStyles.None;
            panel17.BackColor = Color.LightGray;
            panel17.Location = new Point(713, 713);
            panel17.Margin = new Padding(3, 4, 3, 4);
            panel17.Name = "panel17";
            panel17.Size = new Size(1, 73);
            panel17.TabIndex = 73;
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.None;
            panel1.BackColor = Color.LightGray;
            panel1.Location = new Point(97, 713);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(1, 73);
            panel1.TabIndex = 72;
            // 
            // panel15
            // 
            panel15.Anchor = AnchorStyles.None;
            panel15.BackColor = Color.LightGray;
            panel15.Location = new Point(97, 820);
            panel15.Margin = new Padding(3, 4, 3, 4);
            panel15.Name = "panel15";
            panel15.Size = new Size(617, 1);
            panel15.TabIndex = 71;
            // 
            // panel14
            // 
            panel14.Anchor = AnchorStyles.None;
            panel14.BackColor = Color.LightGray;
            panel14.Location = new Point(97, 676);
            panel14.Margin = new Padding(3, 4, 3, 4);
            panel14.Name = "panel14";
            panel14.Size = new Size(617, 1);
            panel14.TabIndex = 70;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.FromArgb(93, 62, 188);
            label3.Location = new Point(342, 41);
            label3.Name = "label3";
            label3.Size = new Size(101, 29);
            label3.TabIndex = 67;
            label3.Text = "KARGO";
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.FromArgb(93, 62, 188);
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(114, 687);
            dataGridView1.Margin = new Padding(3, 4, 3, 4);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(582, 125);
            dataGridView1.TabIndex = 63;
            dataGridView1.CellMouseClick += dataGridView1_CellMouseClick;
            // 
            // panel16
            // 
            panel16.Anchor = AnchorStyles.None;
            panel16.BackColor = Color.LightGray;
            panel16.Location = new Point(-159, 592);
            panel16.Margin = new Padding(3, 4, 3, 4);
            panel16.Name = "panel16";
            panel16.Size = new Size(1, 73);
            panel16.TabIndex = 66;
            // 
            // kargo
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(815, 851);
            Controls.Add(panel2);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "kargo";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "kargo";
            Load += kargo_Load;
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel19.ResumeLayout(false);
            panel19.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            panel12.ResumeLayout(false);
            panel12.PerformLayout();
            panel10.ResumeLayout(false);
            panel10.PerformLayout();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Panel panel2;
        private DataGridView dataGridView1;
        private Panel panel16;
        private Label label3;
        private Panel panel17;
        private Panel panel1;
        private Panel panel15;
        private Panel panel14;
        private Panel panel5;
        private Panel panel6;
        private Label label2;
        private ComboBox comboBox4;
        private Panel panel3;
        private Panel panel4;
        private Label label8;
        private ComboBox comboBox3;
        private Panel panel7;
        private Panel panel18;
        private Label label5;
        private Panel panel12;
        private Panel panel13;
        private Label label7;
        private TextBox textBox3;
        private Panel panel10;
        private Panel panel11;
        private Label label6;
        private TextBox textBox2;
        private Panel panel8;
        private Panel panel9;
        private Label label4;
        private PictureBox pictureBox1;
        private TextBox textBox5;
        private Button button1;
        private ComboBox comboBox2;
        private ComboBox comboBox1;
        private Button button2;
        private Button button3;
        private TextBox textBox1;
        private Panel panel19;
        private Panel panel20;
        private Label label9;
    }
}