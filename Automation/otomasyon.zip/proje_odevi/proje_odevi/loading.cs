﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proje_odevi
{
    public partial class loading : Form
    {
        public loading()
        {
            InitializeComponent();
        }

        // bu kısımda process bar aracından özenilmiş bir kısım bulunmaktadır. process bar özelliğini paneller kullanılarak yapılmış bir kısımdır.
        // (Bu kısım yapılırken bu araç bilinmiyordu daha sonradan öğrenildi :D)

        private void timer1_Tick(object sender, EventArgs e)
        {
            panel2.Width += 3;

            if (panel2.Width > 957)
            {
                timer1.Stop();

                Form1 Menu_Ekrani = new Form1();
                Menu_Ekrani.Show();
                this.Hide();
            }
        }

        private void loading_Load(object sender, EventArgs e)
        {

        }
    }
}
