﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace proje_odevi
{
    public partial class kayit : Form
    {
        public kayit()
        {
            InitializeComponent();
        }

        // Veritabanı bağlantısı oluşturma  

        static string constring = "Data Source=FURKAN\\SQLEXPRESS;Initial Catalog=giris_ekrani;Integrated Security=True;";
        SqlConnection baglanti = new SqlConnection(constring);

        // Bu kısım yapım aşamasında verilerin kayıt edilmesini kısmını kontrol ederken kullanıldı şuanda aktif değildir
        public void kayitlari_goruntule()
        {


            string kayitlari_goruntule = "Select * From Kullanici";

            SqlCommand goruntuleme_komutu = new SqlCommand(kayitlari_goruntule, baglanti);

            SqlDataAdapter Adapter = new SqlDataAdapter(goruntuleme_komutu);

            DataTable DataTable = new DataTable();
            Adapter.Fill(DataTable);
            //dataGridView1.DataSource = DataTable;

            baglanti.Close();
        }

        // Kayıt kısmındaki girelen kodların veri tabanı bağlantısı ile veri tabanına kayıt olmasını sağlayan kısım

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (baglanti.State == ConnectionState.Closed)
                {
                    baglanti.Open();
                    string kaydetme = "insert into Kullanici (Adi, Soyadi, Telefon, Mail, DogumTarihi, Tc,Cinsiyet,Sifre, KullaniciID) values(@Adi, @Soyadi, @Telefon, @Mail, @DogumTarihi, @Tc,@Cinsiyet,@Sifre, @KullaniciID)";


                    SqlCommand kaydetme_komutu = new SqlCommand(kaydetme, baglanti);

                    kaydetme_komutu.Parameters.AddWithValue("@Adi", textBox1.Text);
                    kaydetme_komutu.Parameters.AddWithValue("@Soyadi", textBox2.Text);
                    kaydetme_komutu.Parameters.AddWithValue("@Telefon", maskedTextBox1.Text);
                    kaydetme_komutu.Parameters.AddWithValue("@Mail", maskedTextBox2.Text);
                    kaydetme_komutu.Parameters.AddWithValue("@DogumTarihi", maskedTextBox3.Text);
                    kaydetme_komutu.Parameters.AddWithValue("@Tc", maskedTextBox4.Text);
                    kaydetme_komutu.Parameters.AddWithValue("@Sifre", maskedTextBox5.Text);

                    kaydetme_komutu.Parameters.AddWithValue("@KullaniciID", textBox3.Text);

                    if (radioButton1.Checked == true)
                    {
                        kaydetme_komutu.Parameters.AddWithValue("@Cinsiyet", radioButton1.Text);
                    }

                    else if (radioButton2.Checked == true)
                    {
                        kaydetme_komutu.Parameters.AddWithValue("@Cinsiyet", radioButton2.Text);
                    }

                    if (checkBox1.Checked == true)
                    {



                        kaydetme_komutu.ExecuteNonQuery();

                        MessageBox.Show("Kaydınız Başarılı Bir Şekilde Oluşturuldu. Uygulamamızı Kullanmak İçin Oluşturduğunuz Hesap İle Giriş Yapabilirsiniz.", "Kayıt Sistemi", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }
                }

            }

            catch (Exception kaydedilmedi)
            {

                MessageBox.Show("Kayıt Eklenemedi.", kaydedilmedi.Message);

            }
        }



        private void exit_Click(object sender, EventArgs e)
        {
            giris_ekrani Kayit_Ekrani = new giris_ekrani();
            Kayit_Ekrani.Show();
            this.Hide();
        }

        private void minimize_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            kayitlari_goruntule();
        }

        private void ıconButton1_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel11_Paint(object sender, PaintEventArgs e)
        {

        }

        private void kayit_Load(object sender, EventArgs e)
        {

        }


        // Alt kısımda bulunan çoğu kod text box ve butonlar için özelleştilmiş efektlerin oluşturulduğu kısım

        private void textBox1_MouseClick(object sender, MouseEventArgs e)
        {
            textBox1.SelectAll();
        }

        private void textBox2_MouseClick(object sender, MouseEventArgs e)
        {
            textBox2.SelectAll();
        }

        private void maskedTextBox2_MouseClick(object sender, MouseEventArgs e)
        {
            maskedTextBox2.SelectAll();
        }

        private void textBox3_MouseClick(object sender, MouseEventArgs e)
        {
            textBox3.SelectAll();
        }

        private void maskedTextBox1_MouseClick(object sender, MouseEventArgs e)
        {
            maskedTextBox1.SelectAll();
        }

        private void maskedTextBox3_MouseClick(object sender, MouseEventArgs e)
        {
            maskedTextBox3.SelectAll();
        }

        private void maskedTextBox4_MouseClick(object sender, MouseEventArgs e)
        {
            maskedTextBox4.SelectAll();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            giris_ekrani Kayit_Ekrani = new giris_ekrani();
            Kayit_Ekrani.Show();
            this.Hide();
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(120, 73, 247);
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(93, 62, 188);
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void maskedTextBox5_MouseClick(object sender, MouseEventArgs e)
        {
            maskedTextBox5.SelectAll();
        }

        private void panel17_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
