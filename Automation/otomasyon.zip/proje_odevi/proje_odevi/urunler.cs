﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace proje_odevi
{
    public partial class urunler : Form
    {
        public urunler()
        {
            InitializeComponent();
        }




        // Veritabanı bağlantısı oluşturma  

        static string constring = "Data Source=FURKAN\\SQLEXPRESS;Initial Catalog=Nalbur_DB;Integrated Security=True;";
        SqlConnection baglanti = new SqlConnection(constring);





        // Listele butonu için oluşturduğumuz veri tabanı kayıtlarını data grid view üzerinde gösterdiğimiz fonksiyonun oluşum kısmı


        public void kayitlari_goruntule()
        {


            string kayitlari_goruntule = "Select * From Urunler";

            SqlCommand goruntuleme_komutu = new SqlCommand(kayitlari_goruntule, baglanti);

            SqlDataAdapter Adapter = new SqlDataAdapter(goruntuleme_komutu);

            DataTable DataTable = new DataTable();
            Adapter.Fill(DataTable);
            dataGridView1.DataSource = DataTable;


        }

        // Sil butonu için oluşturduğumuz veri tabanı kayıtlarını silen fonksiyonun oluşum kısmı

        public void kayitlari_sil(int UrunlerID)
        {


            string kayitlari_sil = "Delete From Urunler Where UrunlerID=@UrunlerID";

            SqlCommand silme_komutu = new SqlCommand(kayitlari_sil, baglanti);


            baglanti.Open();

            silme_komutu.Parameters.AddWithValue("@UrunlerID", UrunlerID);

            silme_komutu.ExecuteNonQuery();



            baglanti.Close();
        }

        // Combo boxa veri çekmeği öğrenmeden yazdığımız boş kod yığının oldu kısım 

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                label8.Text = "Boya";
            }

            else if (comboBox1.SelectedIndex == 1)
            {
                label8.Text = "Banyo";
            }

            else if (comboBox1.SelectedIndex == 2)
            {
                label8.Text = "Hırdavat";
            }

            else if (comboBox1.SelectedIndex == 3)
            {
                label8.Text = "Elektrik";
            }

            else if (comboBox1.SelectedIndex == 4)
            {
                label8.Text = "Tesisat";
            }

            else if (comboBox1.SelectedIndex == 5)
            {
                label8.Text = "Yapı Kimyasalları";
            }

            else if (comboBox1.SelectedIndex == 6)
            {
                label8.Text = "İnşaat";
            }

            else if (comboBox1.SelectedIndex == 7)
            {
                label8.Text = "Bahçe";
            }
        }

        // Yukarı kısımdaki arama çubuğu aracılığıyla arama yaptığımız fonksiyonun oluşum kısmı

        private void button1_Click(object sender, EventArgs e)
        {
            string kayitlari_ara = "Select * From Urunler Where UrunAdi=@UrunAdi";

            SqlCommand arama_komutu = new SqlCommand(kayitlari_ara, baglanti);

            arama_komutu.Parameters.AddWithValue("@UrunAdi", textBox5.Text);


            SqlDataAdapter Adapter = new SqlDataAdapter(arama_komutu);

            DataTable DataTable = new DataTable();
            Adapter.Fill(DataTable);
            dataGridView1.DataSource = DataTable;

            baglanti.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            kayitlari_goruntule();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow drow in dataGridView1.SelectedRows)
            {
                int UrunlerID = Convert.ToInt32(drow.Cells[0].Value);
                kayitlari_sil(UrunlerID);
                kayitlari_goruntule();
            }
        }

        // Ekle butonu için veri tabanına ekleme yaptırdığımız fonksiyonun oluşum kısmı

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (baglanti.State == ConnectionState.Closed)
                {
                    baglanti.Open();

                    string kaydetme = "insert into Urunler (UrunAdi, BirimFiyat, StokMiktar, Aciklama,Kategori_ID,Marka_ID) values(@UrunAdi, @BirimFiyat, @StokMiktar, @Aciklama,@Kategori_ID,@Marka_ID)";


                    SqlCommand kaydetme_komutu = new SqlCommand(kaydetme, baglanti);

                    kaydetme_komutu.Parameters.AddWithValue("@UrunAdi", textBox1.Text);
                    kaydetme_komutu.Parameters.AddWithValue("@BirimFiyat", textBox2.Text);
                    kaydetme_komutu.Parameters.AddWithValue("@StokMiktar", textBox3.Text);
                    kaydetme_komutu.Parameters.AddWithValue("@Aciklama", textBox4.Text);



                    kaydetme_komutu.Parameters.AddWithValue("@Kategori_ID", comboBox1.SelectedItem);
                    kaydetme_komutu.Parameters.AddWithValue("@Marka_ID", comboBox2.SelectedItem);




                    kaydetme_komutu.ExecuteNonQuery();

                    MessageBox.Show("Ürün Kaydınız Başarıyla Eklendi.", "Kayıt İşlemi");
                }
            }

            catch (Exception kaydedilmedi)
            {

                MessageBox.Show("Kayıt Eklenemedi.", kaydedilmedi.Message);

            }
        }

        // Combo boxa veri çekmeği öğrenmeden yazdığımız boş kod yığının oldu kısım 

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex == 0)
            {
                label9.Text = "ABC Marka";
            }

            else if (comboBox2.SelectedIndex == 1)
            {
                label9.Text = "XYZ Electronics";
            }

            else if (comboBox2.SelectedIndex == 2)
            {
                label9.Text = "GHI Furniture";
            }

            else if (comboBox2.SelectedIndex == 3)
            {
                label9.Text = "JKL Motors";
            }

            else if (comboBox2.SelectedIndex == 4)
            {
                label9.Text = "MNO Textiles";
            }

            else if (comboBox2.SelectedIndex == 5)
            {
                label9.Text = "PQR Chemicals";
            }

            else if (comboBox2.SelectedIndex == 6)
            {
                label9.Text = "RST Foods";
            }

            else if (comboBox2.SelectedIndex == 7)
            {
                label9.Text = "STU Electronics";
            }

            else if (comboBox2.SelectedIndex == 8)
            {
                label9.Text = "UVW Metals";
            }

            else if (comboBox2.SelectedIndex == 9)
            {
                label9.Text = "LMN Construction";
            }

            else if (comboBox2.SelectedIndex == 10)
            {
                label9.Text = "OPQ Appliances";
            }

            else if (comboBox2.SelectedIndex == 11)
            {
                label9.Text = "EFG Appliances";
            }

            else if (comboBox2.SelectedIndex == 12)
            {
                label9.Text = "HIJ Tools";
            }

            else if (comboBox2.SelectedIndex == 13)
            {
                label9.Text = "KLM Textiles";
            }

            else if (comboBox2.SelectedIndex == 14)
            {
                label9.Text = "NOP Toys";
            }

            else if (comboBox2.SelectedIndex == 15)
            {
                label9.Text = "QRS Kitchenware";
            }

            else if (comboBox2.SelectedIndex == 16)
            {
                label9.Text = "TUV Mobile";
            }

            else if (comboBox2.SelectedIndex == 17)
            {
                label9.Text = "VWX Computers";
            }

            else if (comboBox2.SelectedIndex == 18)
            {
                label9.Text = "YZA Stationery";
            }

            else if (comboBox2.SelectedIndex == 19)
            {
                label9.Text = "BCD Hardware";
            }
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        // Güncelleme butonu için veri tabanı üzerinden verileri güncellediğimiz fonksiyonu oluşturduğumuz kısım


        int sayac = 0;
        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                if (baglanti.State == ConnectionState.Closed)
                {
                    baglanti.Open();

                    string güncelleme = "UPDATE Urunler SET UrunAdi=@UrunAdi, BirimFiyat=@BirimFiyat, StokMiktar=@StokMiktar, Aciklama=@Aciklama, Kategori_ID=@Kategori_ID, Marka_ID=@Marka_ID WHERE UrunlerID=@UrunlerID";

                    SqlCommand güncelleme_komutu = new SqlCommand(güncelleme, baglanti);

                    güncelleme_komutu.Parameters.AddWithValue("@UrunAdi", textBox1.Text);
                    güncelleme_komutu.Parameters.AddWithValue("@BirimFiyat", textBox2.Text);
                    güncelleme_komutu.Parameters.AddWithValue("@StokMiktar", textBox3.Text);
                    güncelleme_komutu.Parameters.AddWithValue("@Aciklama", textBox4.Text);
                    güncelleme_komutu.Parameters.AddWithValue("@Kategori_ID", comboBox1.SelectedItem);
                    güncelleme_komutu.Parameters.AddWithValue("@Marka_ID", comboBox2.SelectedItem);

                    güncelleme_komutu.Parameters.AddWithValue("@UrunlerID", dataGridView1.Rows[sayac].Cells["UrunlerID"].Value);


                    güncelleme_komutu.ExecuteNonQuery();

                    MessageBox.Show("Ürün Kaydınız Başarıyla Güncellendi.", "Güncelleme İşlemi");
                    kayitlari_goruntule();
                }


                else
                {
                    MessageBox.Show("Ürün Kaydı Güncellenmedi.");
                }




            }
            catch (Exception hata)
            {
                MessageBox.Show("Güncelleme Hatası: " + hata.Message);
            }
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            sayac = e.RowIndex;

            textBox1.Text = dataGridView1.Rows[sayac].Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.Rows[sayac].Cells[2].Value.ToString();
            textBox3.Text = dataGridView1.Rows[sayac].Cells[3].Value.ToString();
            textBox4.Text = dataGridView1.Rows[sayac].Cells[4].Value.ToString();

            comboBox2.SelectedItem = dataGridView1.Rows[sayac].Cells[6].Value.ToString();
            comboBox1.SelectedItem = dataGridView1.Rows[sayac].Cells[5].Value.ToString();
        }

        // Buton efektlerinin bulunduğu fonksiyonun kısmı 

        private void button3_MouseEnter(object sender, EventArgs e)
        {
            button3.BackColor = Color.FromArgb(120, 73, 247);
        }

        private void button3_MouseLeave(object sender, EventArgs e)
        {
            button3.BackColor = Color.FromArgb(93, 62, 188);
        }

        private void button4_MouseEnter(object sender, EventArgs e)
        {
            button4.BackColor = Color.FromArgb(120, 73, 247);
        }

        private void button4_MouseLeave(object sender, EventArgs e)
        {
            button4.BackColor = Color.FromArgb(93, 62, 188);
        }

        private void button5_MouseEnter(object sender, EventArgs e)
        {
            button5.BackColor = Color.FromArgb(120, 73, 247);
        }

        private void button5_MouseLeave(object sender, EventArgs e)
        {
            button5.BackColor = Color.FromArgb(93, 62, 188);
        }

        private void button2_MouseEnter(object sender, EventArgs e)
        {
            button2.BackColor = Color.FromArgb(120, 73, 247);
        }

        private void button2_MouseLeave(object sender, EventArgs e)
        {
            button2.BackColor = Color.FromArgb(93, 62, 188);
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(120, 73, 247);
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            button1.BackColor = Color.FromArgb(93, 62, 188);
        }
    }

}


