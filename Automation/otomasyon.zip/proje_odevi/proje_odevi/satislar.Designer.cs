﻿namespace proje_odevi
{
    partial class satislar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(satislar));
            label1 = new Label();
            panel3 = new Panel();
            button3 = new Button();
            pictureBox1 = new PictureBox();
            textBox6 = new TextBox();
            panel14 = new Panel();
            panel15 = new Panel();
            label16 = new Label();
            textBox5 = new TextBox();
            panel12 = new Panel();
            panel13 = new Panel();
            label11 = new Label();
            comboBox3 = new ComboBox();
            panel16 = new Panel();
            maskedTextBox1 = new MaskedTextBox();
            panel17 = new Panel();
            label17 = new Label();
            panel10 = new Panel();
            panel11 = new Panel();
            label12 = new Label();
            comboBox2 = new ComboBox();
            panel8 = new Panel();
            panel9 = new Panel();
            label13 = new Label();
            comboBox1 = new ComboBox();
            panel6 = new Panel();
            panel7 = new Panel();
            label14 = new Label();
            textBox2 = new TextBox();
            panel4 = new Panel();
            label4 = new Label();
            panel5 = new Panel();
            label15 = new Label();
            textBox3 = new TextBox();
            panel1 = new Panel();
            panel2 = new Panel();
            label18 = new Label();
            textBox1 = new TextBox();
            panel21 = new Panel();
            panel20 = new Panel();
            panel18 = new Panel();
            panel19 = new Panel();
            button4 = new Button();
            button2 = new Button();
            button1 = new Button();
            dataGridView1 = new DataGridView();
            label3 = new Label();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel14.SuspendLayout();
            panel12.SuspendLayout();
            panel16.SuspendLayout();
            panel10.SuspendLayout();
            panel8.SuspendLayout();
            panel6.SuspendLayout();
            panel4.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(437, 291);
            label1.Name = "label1";
            label1.Size = new Size(55, 20);
            label1.TabIndex = 1;
            label1.Text = "satislar";
            label1.Click += label1_Click;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(247, 247, 247);
            panel3.Controls.Add(button3);
            panel3.Controls.Add(pictureBox1);
            panel3.Controls.Add(textBox6);
            panel3.Controls.Add(panel14);
            panel3.Controls.Add(panel12);
            panel3.Controls.Add(panel16);
            panel3.Controls.Add(panel10);
            panel3.Controls.Add(panel8);
            panel3.Controls.Add(panel6);
            panel3.Controls.Add(panel4);
            panel3.Controls.Add(panel1);
            panel3.Controls.Add(panel21);
            panel3.Controls.Add(panel20);
            panel3.Controls.Add(panel18);
            panel3.Controls.Add(panel19);
            panel3.Controls.Add(button4);
            panel3.Controls.Add(button2);
            panel3.Controls.Add(button1);
            panel3.Controls.Add(dataGridView1);
            panel3.Controls.Add(label3);
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(0, 0);
            panel3.Margin = new Padding(3, 4, 3, 4);
            panel3.Name = "panel3";
            panel3.Size = new Size(815, 851);
            panel3.TabIndex = 4;
            panel3.Paint += panel3_Paint;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(93, 62, 188);
            button3.FlatAppearance.BorderColor = Color.FromArgb(93, 62, 188);
            button3.FlatAppearance.BorderSize = 2;
            button3.FlatStyle = FlatStyle.Flat;
            button3.ForeColor = Color.White;
            button3.Location = new Point(314, 111);
            button3.Margin = new Padding(3, 4, 3, 4);
            button3.Name = "button3";
            button3.Size = new Size(171, 40);
            button3.TabIndex = 97;
            button3.Text = "Satış Ara";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(685, 173);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(22, 23);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 96;
            pictureBox1.TabStop = false;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(95, 171);
            textBox6.Margin = new Padding(3, 4, 3, 4);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(617, 27);
            textBox6.TabIndex = 95;
            // 
            // panel14
            // 
            panel14.BackColor = Color.Transparent;
            panel14.Controls.Add(panel15);
            panel14.Controls.Add(label16);
            panel14.Controls.Add(textBox5);
            panel14.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel14.ForeColor = Color.Transparent;
            panel14.Location = new Point(280, 232);
            panel14.Margin = new Padding(3, 4, 3, 4);
            panel14.Name = "panel14";
            panel14.Size = new Size(248, 112);
            panel14.TabIndex = 94;
            // 
            // panel15
            // 
            panel15.Anchor = AnchorStyles.None;
            panel15.BackColor = Color.LightGray;
            panel15.Location = new Point(8, 81);
            panel15.Margin = new Padding(3, 4, 3, 4);
            panel15.Name = "panel15";
            panel15.Size = new Size(237, 1);
            panel15.TabIndex = 30;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.BackColor = Color.Transparent;
            label16.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label16.ForeColor = Color.FromArgb(93, 62, 188);
            label16.Location = new Point(0, 0);
            label16.Name = "label16";
            label16.Size = new Size(33, 15);
            label16.TabIndex = 56;
            label16.Text = "Adet";
            // 
            // textBox5
            // 
            textBox5.Location = new Point(9, 43);
            textBox5.Margin = new Padding(3, 4, 3, 4);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(231, 21);
            textBox5.TabIndex = 77;
            // 
            // panel12
            // 
            panel12.BackColor = Color.Transparent;
            panel12.Controls.Add(panel13);
            panel12.Controls.Add(label11);
            panel12.Controls.Add(comboBox3);
            panel12.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel12.ForeColor = Color.Transparent;
            panel12.Location = new Point(25, 232);
            panel12.Margin = new Padding(3, 4, 3, 4);
            panel12.Name = "panel12";
            panel12.Size = new Size(248, 112);
            panel12.TabIndex = 92;
            // 
            // panel13
            // 
            panel13.Anchor = AnchorStyles.None;
            panel13.BackColor = Color.LightGray;
            panel13.Location = new Point(8, 83);
            panel13.Margin = new Padding(3, 4, 3, 4);
            panel13.Name = "panel13";
            panel13.Size = new Size(237, 1);
            panel13.TabIndex = 30;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.Transparent;
            label11.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label11.ForeColor = Color.FromArgb(93, 62, 188);
            label11.Location = new Point(0, 0);
            label11.Name = "label11";
            label11.Size = new Size(59, 15);
            label11.TabIndex = 56;
            label11.Text = "Ürün Seç";
            // 
            // comboBox3
            // 
            comboBox3.FormattingEnabled = true;
            comboBox3.Location = new Point(9, 44);
            comboBox3.Margin = new Padding(3, 4, 3, 4);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(231, 23);
            comboBox3.TabIndex = 75;
            // 
            // panel16
            // 
            panel16.BackColor = Color.Transparent;
            panel16.Controls.Add(maskedTextBox1);
            panel16.Controls.Add(panel17);
            panel16.Controls.Add(label17);
            panel16.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel16.ForeColor = Color.Transparent;
            panel16.Location = new Point(150, 497);
            panel16.Margin = new Padding(3, 4, 3, 4);
            panel16.Name = "panel16";
            panel16.Size = new Size(248, 112);
            panel16.TabIndex = 93;
            // 
            // maskedTextBox1
            // 
            maskedTextBox1.Location = new Point(6, 45);
            maskedTextBox1.Margin = new Padding(3, 4, 3, 4);
            maskedTextBox1.Mask = "00/00/0000";
            maskedTextBox1.Name = "maskedTextBox1";
            maskedTextBox1.Size = new Size(235, 21);
            maskedTextBox1.TabIndex = 98;
            maskedTextBox1.ValidatingType = typeof(DateTime);
            // 
            // panel17
            // 
            panel17.Anchor = AnchorStyles.None;
            panel17.BackColor = Color.LightGray;
            panel17.Location = new Point(5, 81);
            panel17.Margin = new Padding(3, 4, 3, 4);
            panel17.Name = "panel17";
            panel17.Size = new Size(237, 1);
            panel17.TabIndex = 30;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.BackColor = Color.Transparent;
            label17.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label17.ForeColor = Color.FromArgb(93, 62, 188);
            label17.Location = new Point(0, 0);
            label17.Name = "label17";
            label17.Size = new Size(81, 15);
            label17.TabIndex = 56;
            label17.Text = "Sipariş Tarihi";
            // 
            // panel10
            // 
            panel10.BackColor = Color.Transparent;
            panel10.Controls.Add(panel11);
            panel10.Controls.Add(label12);
            panel10.Controls.Add(comboBox2);
            panel10.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel10.ForeColor = Color.Transparent;
            panel10.Location = new Point(535, 232);
            panel10.Margin = new Padding(3, 4, 3, 4);
            panel10.Name = "panel10";
            panel10.Size = new Size(248, 112);
            panel10.TabIndex = 90;
            // 
            // panel11
            // 
            panel11.Anchor = AnchorStyles.None;
            panel11.BackColor = Color.LightGray;
            panel11.Location = new Point(8, 77);
            panel11.Margin = new Padding(3, 4, 3, 4);
            panel11.Name = "panel11";
            panel11.Size = new Size(237, 1);
            panel11.TabIndex = 30;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.Transparent;
            label12.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label12.ForeColor = Color.FromArgb(93, 62, 188);
            label12.Location = new Point(0, 0);
            label12.Name = "label12";
            label12.Size = new Size(97, 15);
            label12.TabIndex = 56;
            label12.Text = "Ödeme Yöntemi";
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "Nakit ", "Kapıda Ödeme", "Kredi Kartı", "Havale", "Çek" });
            comboBox2.Location = new Point(8, 39);
            comboBox2.Margin = new Padding(3, 4, 3, 4);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(233, 23);
            comboBox2.TabIndex = 67;
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // panel8
            // 
            panel8.BackColor = Color.Transparent;
            panel8.Controls.Add(panel9);
            panel8.Controls.Add(label13);
            panel8.Controls.Add(comboBox1);
            panel8.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel8.ForeColor = Color.Transparent;
            panel8.Location = new Point(280, 364);
            panel8.Margin = new Padding(3, 4, 3, 4);
            panel8.Name = "panel8";
            panel8.Size = new Size(248, 112);
            panel8.TabIndex = 88;
            // 
            // panel9
            // 
            panel9.Anchor = AnchorStyles.None;
            panel9.BackColor = Color.LightGray;
            panel9.Location = new Point(5, 73);
            panel9.Margin = new Padding(3, 4, 3, 4);
            panel9.Name = "panel9";
            panel9.Size = new Size(237, 1);
            panel9.TabIndex = 30;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.Transparent;
            label13.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label13.ForeColor = Color.FromArgb(93, 62, 188);
            label13.Location = new Point(0, 0);
            label13.Name = "label13";
            label13.Size = new Size(95, 15);
            label13.TabIndex = 56;
            label13.Text = "Sipariş Durumu";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Dükkanda Satış", "Hazırlanıyor" });
            comboBox1.Location = new Point(5, 35);
            comboBox1.Margin = new Padding(3, 4, 3, 4);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(236, 23);
            comboBox1.TabIndex = 66;
            // 
            // panel6
            // 
            panel6.BackColor = Color.Transparent;
            panel6.Controls.Add(panel7);
            panel6.Controls.Add(label14);
            panel6.Controls.Add(textBox2);
            panel6.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel6.ForeColor = Color.Transparent;
            panel6.Location = new Point(25, 364);
            panel6.Margin = new Padding(3, 4, 3, 4);
            panel6.Name = "panel6";
            panel6.Size = new Size(248, 112);
            panel6.TabIndex = 91;
            // 
            // panel7
            // 
            panel7.Anchor = AnchorStyles.None;
            panel7.BackColor = Color.LightGray;
            panel7.Location = new Point(5, 83);
            panel7.Margin = new Padding(3, 4, 3, 4);
            panel7.Name = "panel7";
            panel7.Size = new Size(237, 1);
            panel7.TabIndex = 30;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.BackColor = Color.Transparent;
            label14.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label14.ForeColor = Color.FromArgb(93, 62, 188);
            label14.Location = new Point(0, 0);
            label14.Name = "label14";
            label14.Size = new Size(54, 15);
            label14.TabIndex = 56;
            label14.Text = "Detaylar";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(5, 44);
            textBox2.Margin = new Padding(3, 4, 3, 4);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(236, 21);
            textBox2.TabIndex = 63;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Transparent;
            panel4.Controls.Add(label4);
            panel4.Controls.Add(panel5);
            panel4.Controls.Add(label15);
            panel4.Controls.Add(textBox3);
            panel4.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel4.ForeColor = Color.Transparent;
            panel4.Location = new Point(405, 497);
            panel4.Margin = new Padding(3, 4, 3, 4);
            panel4.Name = "panel4";
            panel4.Size = new Size(248, 112);
            panel4.TabIndex = 89;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.Red;
            label4.Location = new Point(3, 81);
            label4.Name = "label4";
            label4.Size = new Size(182, 15);
            label4.TabIndex = 98;
            label4.Text = "Birim Fiyatı Ve Adet Boş Olamaz.";
            label4.Visible = false;
            // 
            // panel5
            // 
            panel5.Anchor = AnchorStyles.None;
            panel5.BackColor = Color.LightGray;
            panel5.Location = new Point(5, 77);
            panel5.Margin = new Padding(3, 4, 3, 4);
            panel5.Name = "panel5";
            panel5.Size = new Size(237, 1);
            panel5.TabIndex = 30;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.BackColor = Color.Transparent;
            label15.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label15.ForeColor = Color.FromArgb(93, 62, 188);
            label15.Location = new Point(0, 0);
            label15.Name = "label15";
            label15.Size = new Size(80, 15);
            label15.TabIndex = 56;
            label15.Text = "Toplam Tutar";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(5, 43);
            textBox3.Margin = new Padding(3, 4, 3, 4);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(236, 21);
            textBox3.TabIndex = 64;
            textBox3.TextChanged += textBox3_TextChanged;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Transparent;
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(label18);
            panel1.Controls.Add(textBox1);
            panel1.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            panel1.ForeColor = Color.Transparent;
            panel1.Location = new Point(535, 364);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(248, 112);
            panel1.TabIndex = 87;
            panel1.Paint += panel1_Paint;
            // 
            // panel2
            // 
            panel2.Anchor = AnchorStyles.None;
            panel2.BackColor = Color.LightGray;
            panel2.Location = new Point(5, 73);
            panel2.Margin = new Padding(3, 4, 3, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(237, 1);
            panel2.TabIndex = 30;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.BackColor = Color.Transparent;
            label18.Font = new Font("Arial", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label18.ForeColor = Color.FromArgb(93, 62, 188);
            label18.Location = new Point(0, 0);
            label18.Name = "label18";
            label18.Size = new Size(69, 15);
            label18.TabIndex = 56;
            label18.Text = "Birim Fiyatı";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(5, 37);
            textBox1.Margin = new Padding(3, 4, 3, 4);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(236, 21);
            textBox1.TabIndex = 62;
            // 
            // panel21
            // 
            panel21.Anchor = AnchorStyles.None;
            panel21.BackColor = Color.LightGray;
            panel21.Location = new Point(97, 723);
            panel21.Margin = new Padding(3, 4, 3, 4);
            panel21.Name = "panel21";
            panel21.Size = new Size(1, 73);
            panel21.TabIndex = 86;
            // 
            // panel20
            // 
            panel20.Anchor = AnchorStyles.None;
            panel20.BackColor = Color.LightGray;
            panel20.Location = new Point(97, 832);
            panel20.Margin = new Padding(3, 4, 3, 4);
            panel20.Name = "panel20";
            panel20.Size = new Size(617, 1);
            panel20.TabIndex = 85;
            // 
            // panel18
            // 
            panel18.Anchor = AnchorStyles.None;
            panel18.BackColor = Color.LightGray;
            panel18.Location = new Point(713, 723);
            panel18.Margin = new Padding(3, 4, 3, 4);
            panel18.Name = "panel18";
            panel18.Size = new Size(1, 73);
            panel18.TabIndex = 84;
            // 
            // panel19
            // 
            panel19.Anchor = AnchorStyles.None;
            panel19.BackColor = Color.LightGray;
            panel19.Location = new Point(97, 688);
            panel19.Margin = new Padding(3, 4, 3, 4);
            panel19.Name = "panel19";
            panel19.Size = new Size(617, 1);
            panel19.TabIndex = 83;
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(93, 62, 188);
            button4.FlatAppearance.BorderColor = Color.FromArgb(93, 62, 188);
            button4.FlatAppearance.BorderSize = 2;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button4.ForeColor = Color.White;
            button4.Location = new Point(338, 633);
            button4.Margin = new Padding(3, 4, 3, 4);
            button4.Name = "button4";
            button4.Size = new Size(128, 47);
            button4.TabIndex = 81;
            button4.Text = "Satış Sil";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(93, 62, 188);
            button2.FlatAppearance.BorderColor = Color.FromArgb(93, 62, 188);
            button2.FlatAppearance.BorderSize = 2;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button2.ForeColor = Color.White;
            button2.Location = new Point(482, 633);
            button2.Margin = new Padding(3, 4, 3, 4);
            button2.Name = "button2";
            button2.Size = new Size(134, 47);
            button2.TabIndex = 80;
            button2.Text = "Satışları Listele";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(93, 62, 188);
            button1.FlatAppearance.BorderColor = Color.FromArgb(93, 62, 188);
            button1.FlatAppearance.BorderSize = 2;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button1.ForeColor = Color.White;
            button1.Location = new Point(194, 633);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(128, 47);
            button1.TabIndex = 79;
            button1.Text = "Satış Ekle";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.FromArgb(93, 62, 188);
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(114, 700);
            dataGridView1.Margin = new Padding(3, 4, 3, 4);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(582, 125);
            dataGridView1.TabIndex = 68;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.FromArgb(93, 62, 188);
            label3.Location = new Point(330, 43);
            label3.Name = "label3";
            label3.Size = new Size(131, 29);
            label3.TabIndex = 61;
            label3.Text = "SATIŞLAR";
            // 
            // satislar
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(815, 851);
            Controls.Add(panel3);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "satislar";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "satislar";
            Load += satislar_Load;
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel14.ResumeLayout(false);
            panel14.PerformLayout();
            panel12.ResumeLayout(false);
            panel12.PerformLayout();
            panel16.ResumeLayout(false);
            panel16.PerformLayout();
            panel10.ResumeLayout(false);
            panel10.PerformLayout();
            panel8.ResumeLayout(false);
            panel8.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Panel panel3;
        private Label label3;
        private TextBox textBox5;
        private ComboBox comboBox3;
        private DataGridView dataGridView1;
        private ComboBox comboBox2;
        private ComboBox comboBox1;
        private TextBox textBox3;
        private TextBox textBox2;
        private TextBox textBox1;
        private Button button4;
        private Button button2;
        private Button button1;
        private Panel panel18;
        private Panel panel19;
        private Panel panel21;
        private Panel panel20;
        private Panel panel14;
        private Panel panel15;
        private Label label16;
        private Panel panel12;
        private Panel panel13;
        private Label label11;
        private Panel panel16;
        private Panel panel17;
        private Label label17;
        private Panel panel10;
        private Panel panel11;
        private Label label12;
        private Panel panel8;
        private Panel panel9;
        private Label label13;
        private Panel panel6;
        private Panel panel7;
        private Label label14;
        private Panel panel4;
        private Panel panel5;
        private Label label15;
        private Panel panel1;
        private Panel panel2;
        private Label label18;
        private PictureBox pictureBox1;
        private TextBox textBox6;
        private Button button3;
        private MaskedTextBox maskedTextBox1;
        private Label label4;
    }
}